#!/bin/sh
# run_on_target.sh —— 在目标机（darwin-arm64）上验收这批交叉编译的二进制：真跑 golden，全过才是交付件。
#   有 python3 ⇒ 走完整的「冒烟八条 + 打包」（与 Windows 上出包同一个脚本）；没有 ⇒ 至少跑命令行 selftest。
cd "$(dirname "$0")"
chmod +x prebuilt/fry-sim-cli prebuilt/FrySimDemoC 2>/dev/null
if command -v xattr >/dev/null 2>&1; then xattr -dr com.apple.quarantine . 2>/dev/null; fi
if command -v python3 >/dev/null 2>&1; then
  python3 tools/fry_build.py --version 1.1.1 --prebuilt-dir prebuilt | tee target_result.txt
else
  ./prebuilt/fry-sim-cli selftest --golden tests/golden | tee target_result.txt
fi
