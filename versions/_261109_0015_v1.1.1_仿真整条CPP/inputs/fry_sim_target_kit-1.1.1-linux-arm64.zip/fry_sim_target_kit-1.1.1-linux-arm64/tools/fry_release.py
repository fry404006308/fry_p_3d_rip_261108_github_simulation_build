# -*- coding: utf-8 -*-
r"""fry_release.py —— 一键出包：算法仓改了仿真 C++ 之后，从同步到交付一条命令走完（界面 HS400 / fry_release.bat 都调它）。

【七步】（任何一步红 ⇒ 停下，后面不做；每一步的结论都写进 out/release/<时间>_v<版本>/release_report.json）
  ① 找算法仓：--algo-repo > 环境变量 FRY_ALGO_REPO > 本仓同级的 fry_py_260604_c180_depth_dither_more
  ② 载荷：算法仓 fry_sim_cpp 变了 ⇒ sync（拷进 cpp/ + 重写 cpp.lock.json）；没变 ⇒ 跳过
  ③ golden：与载荷不配套（或不存在）⇒ 用算法仓的 Python 重新算标准答案
  ④ 版本号：--version auto ⇒ 载荷指纹与上一次发布相同 = 沿用上一个版本号（重出同一版），不同 = 末位 +1；也可手填
  ⑤ 本机出包：编译 + 冒烟八条（含 golden 逐位）+ 打包（Windows 上就是 win32-x64 的 dll 包）
  ⑥ 交叉编译（--cross auto：找得到 zig 就编 linux-x64 / linux-arm64 / darwin-arm64 / darwin-x64）+ 验收：
       linux-x64：Windows 上有 WSL 就在 WSL 里真跑一遍（变成已验证的包）；Linux 宿主当场跑；
       macOS / linux-arm64：出「目标机验收包」，拿到对应机器上 sh run_on_target.sh
  ⑦ 交付：已验证的包拷进算法仓 rip_components/fry_kernel/_bin/fry_sim/<平台>/（--no-deliver 跳过）
  最后：所有包 / 验收包汇总到 out/release/_<YYMMDD_HHMM>_v<版本>/，并追加一行 release_history.json（进 git，可追溯）。

用法：
  python tools/fry_release.py                       # 全自动
  python tools/fry_release.py --version 1.1.0 --cross none --no-deliver
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build as FB      # noqa: E402
import fry_payload          # noqa: E402

ALGO_DIRNAME_STR = "fry_py_260604_c180_depth_dither_more"
HISTORY_PATH = REPO / "release_history.json"
VERSION_PATH = REPO / "VERSION"
CROSS_ALL_STR = "linux-x64,linux-arm64,darwin-arm64,darwin-x64"


def say(t: str) -> None:
    print(t, flush=True)


def locate_algo(given: str) -> Path:
    for cand in (given, os.environ.get("FRY_ALGO_REPO", ""), str(REPO.parent / ALGO_DIRNAME_STR)):
        if cand and (Path(cand) / "fry_sim_cpp" / "CMakeLists.txt").is_file():
            return Path(cand).resolve()
    raise SystemExit("✗ 找不到算法仓：用 --algo-repo 指定，或设环境变量 FRY_ALGO_REPO（查过：参数 / 环境变量 / %s）"
                     % (REPO.parent / ALGO_DIRNAME_STR))


def read_history() -> List[Dict[str, Any]]:
    if not HISTORY_PATH.is_file():
        return []
    return json.loads(HISTORY_PATH.read_text(encoding="utf-8")).get("releases_list", [])


def next_version(fingerprint: str, history: List[Dict[str, Any]], base: str, wrapper: str = "", api: int = 1) -> str:
    """纯函数：同一份载荷 + 同一份外壳 ⇒ 同一个版本号（重出同一版）；任何一个变了 ⇒ 在「上一次发布」与 VERSION 文件里取大的那个，末位 +1。
    外壳 = 头文件 / SDK 源码 / CMake（改了它库的字节就变，版本号必须跟着变）；老记录没有外壳指纹 ⇒ 当作「不知道一样」⇒ 升号（宁可多升一次）。
    ★458 **接口版本**（头文件 FRY_SIM_SDK_API_VERSION）变了 ⇒ 升**中间位**、末位归零（1.0.1 → 1.1.0）：消费方一看版本号就知道「有新函数」；
      老记录没写接口版本 ⇒ 当作 1（456 的两版都是接口 1）。"""
    if history and history[-1].get("fingerprint_str") == fingerprint and \
            history[-1].get("wrapper_sha256_str") == wrapper and int(history[-1].get("api_version_int", 1)) == int(api):
        return history[-1]["version_str"]
    cands = [base] + [h["version_str"] for h in history]
    top = max(cands, key=lambda v: tuple(int(x) for x in v.split("-")[0].split(".")))
    a, b, c = (int(x) for x in top.split("-")[0].split("."))
    if not history:
        return "%d.%d.%d" % (a, b, c)              # 第一次发布：就用 VERSION 文件里的号
    if int(history[-1].get("api_version_int", 1)) != int(api):
        return "%d.%d.0" % (a, b + 1)
    return "%d.%d.%d" % (a, b, c + 1)


def run_step(name: str, cmd: List[str], log: List[Dict[str, Any]], timeout: int = 7200) -> int:
    say("\n【%s】$ %s" % (name, " ".join(cmd)))
    t0 = time.time()
    proc = subprocess.Popen(cmd, cwd=str(REPO), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
    tail: List[str] = []
    for raw in proc.stdout:
        line = raw.decode("utf-8", "replace").rstrip("\r\n")
        print("   " + line, flush=True)
        tail = (tail + [line])[-60:]
    rc = proc.wait(timeout=timeout)
    log.append({"step_str": name, "rc_int": rc, "seconds_float": round(time.time() - t0, 1), "tail_list": tail[-25:]})
    return rc


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="仿真 SDK 一键出包")
    ap.add_argument("--algo-repo", default="")
    ap.add_argument("--python", default=sys.executable, help="算法仓的 Python（算 golden 要 numpy / scipy）")
    ap.add_argument("--version", default="auto")
    ap.add_argument("--cross", default="auto", help="auto（有 zig 就全编）/ none / all / 逗号分隔的目标")
    ap.add_argument("--no-deliver", action="store_true")
    ap.add_argument("--result-json", default="")
    ns = ap.parse_args(argv)
    t0 = time.time()
    steps: List[Dict[str, Any]] = []
    algo = locate_algo(ns.algo_repo)
    py = [ns.python, "-X", "utf8"]
    say("=" * 88)
    say("仿真 SDK 一键出包 ｜ 宿主 %s ｜ 算法仓 %s" % (FB.host_tag(), algo))
    say("=" * 88)
    result: Dict[str, Any] = {"ok_bool": False, "algo_repo_str": str(algo), "host_str": FB.host_tag(), "steps_list": steps}

    def finish(ok: bool, why: str = "") -> int:
        result.update(ok_bool=ok, why_str=why, total_s_float=round(time.time() - t0, 1))
        # 给界面 HS400（经 TR100 命令模式）看的两样：一句话结论 + 关键产物（TR100 以 ok_bool + 返回码判成败）
        if ok:
            result["message_str"] = "仿真 SDK v%s 出包完成：已验证 %s；待目标机验收 %d 个；交付 %d 个平台进算法仓" % (
                result.get("version_str", "?"), "、".join(result.get("verified_platforms_list") or []) or "无",
                len(result.get("unverified_kits_list") or []), sum(1 for d in result.get("deliver_list") or [] if d.get("ok_bool")))
        else:
            result["message_str"] = "仿真 SDK 出包停在：%s（日志里有每一步的输出）" % why
        result["key_output_dict"] = {k: result.get(k) for k in ("version_str", "fingerprint_str", "release_dir_str",
                                                                 "verified_platforms_list", "unverified_kits_list")}
        result["key_output_dict"]["delivered_dir_list"] = [d.get("dir_str") for d in result.get("deliver_list") or [] if d.get("ok_bool")]
        result["output_path_str"] = result.get("release_dir_str") or str(REPO / "out")
        if ns.result_json:
            Path(ns.result_json).write_text(json.dumps(result, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        say("\n%s %s（%.0f s）" % ("✓ 一键出包完成" if ok else "✗ 一键出包停在：", why, result["total_s_float"]))
        return 0 if ok else 1

    # ② 载荷
    st = fry_payload.status(algo) if (REPO / "cpp.lock.json").is_file() else {"up_to_date_bool": False}
    if not st["up_to_date_bool"] or not fry_payload.check()["ok_bool"]:
        if run_step("② 同步载荷", py + [str(REPO / "tools" / "fry_payload.py"), "sync", "--source", str(algo)], steps):
            return finish(False, "② 同步载荷")
    else:
        say("\n【② 载荷】算法仓 fry_sim_cpp 与上次同步一致，跳过")
    fp = FB.lock_fingerprint()
    # ③ golden
    import fry_make_golden
    if not fry_make_golden.verify_manifest()["ok_bool"]:
        if run_step("③ 生成 golden", py + [str(REPO / "tools" / "fry_make_golden.py"), "--source", str(algo)], steps):
            return finish(False, "③ golden（算法仓 Python 环境要有 numpy / scipy）")
    else:
        say("【③ golden】与载荷配套，跳过")
    # ④ 版本号
    history = read_history()
    base = VERSION_PATH.read_text(encoding="utf-8").strip() if VERSION_PATH.is_file() else "1.0.0"
    wrapper = FB.wrapper_fingerprint()
    version = next_version(fp, history, base, wrapper, FB.header_api_version()) if ns.version == "auto" else ns.version
    VERSION_PATH.write_text(version + "\n", encoding="utf-8", newline="\n")
    result.update(version_str=version, fingerprint_str=fp)
    say("【④ 版本号】%s（载荷指纹 %s；上一次发布 %s）" % (version, fp[:16], history[-1]["version_str"] if history else "无"))
    # ⑤ 本机
    if run_step("⑤ 本机出包", py + [str(REPO / "tools" / "fry_build.py"), "--version", version], steps):
        return finish(False, "⑤ 本机出包（冒烟没过就不出包）")
    # ⑥ 交叉
    cross_rows: List[Dict[str, Any]] = []
    targets = ""
    if ns.cross == "auto":
        try:
            import fry_cross_build
            fry_cross_build.find_zig()
            fry_cross_build.find_ninja()
            targets = CROSS_ALL_STR
        except SystemExit as e:
            say("【⑥ 交叉编译】跳过：%s" % e)
    elif ns.cross == "all":
        targets = CROSS_ALL_STR
    elif ns.cross != "none":
        targets = ns.cross
    if targets:
        verify_host = ["--verify-host"] if FB.host_tag() in targets.split(",") else []
        run_step("⑥ 交叉编译", py + [str(REPO / "tools" / "fry_cross_build.py"), "--target", targets, "--version", version] + verify_host, steps)
        ci = REPO / "out" / "cross" / "cross_info.json"
        cross_rows = json.loads(ci.read_text(encoding="utf-8"))["targets_list"] if ci.is_file() else []
        if "linux-x64" in targets.split(",") and FB.host_tag().startswith("win32") and shutil.which("wsl"):
            rc = run_step("⑥ WSL 验收 linux-x64", py + [str(REPO / "tools" / "fry_wsl_verify.py"), "--target", "linux-x64"], steps)
            for r in cross_rows:
                if r["target_str"] == "linux-x64" and rc == 0:
                    r["verified_on_target_bool"] = True
                    r["verify_note_str"] = "WSL（真 Linux）里跑过冒烟八条（含 golden）"
    result["cross_list"] = [{k: r.get(k) for k in ("target_str", "ok_bool", "verified_on_target_bool", "verify_note_str",
                                                     "static_problems_list")} for r in cross_rows]
    # 汇总
    stamp = time.strftime("%y%m%d_%H%M")
    rel = REPO / "out" / "release" / ("_%s_v%s" % (stamp, version))
    rel.mkdir(parents=True, exist_ok=True)
    pkgs = sorted(p for p in (REPO / "out" / "package").glob("fry_sim_sdk-%s-*.zip" % version))
    for p in pkgs:
        shutil.copy2(p, rel / p.name)
    verified_tags = {p.name[len("fry_sim_sdk-%s-" % version):-4] for p in pkgs}
    for r in cross_rows:
        if r["target_str"] not in verified_tags and r.get("kit_str") and Path(r["kit_str"]).is_file():
            shutil.copy2(r["kit_str"], rel / Path(r["kit_str"]).name)
    result["packages_list"] = [p.name for p in pkgs]
    result["verified_platforms_list"] = sorted(verified_tags)
    result["unverified_kits_list"] = sorted(p.name for p in rel.glob("fry_sim_target_kit-*.zip"))
    # ⑦ 交付
    if not ns.no_deliver:
        dj = REPO / "out" / "deliver_result.json"
        args = py + [str(REPO / "tools" / "fry_deliver.py"), "--algo-repo", str(algo), "--result-json", str(dj)]
        for p in pkgs:
            args += ["--package", str(REPO / "out" / "package" / p.name[:-4])]
        if run_step("⑦ 交付进算法仓", args, steps):
            return finish(False, "⑦ 交付")
        result["deliver_list"] = json.loads(dj.read_text(encoding="utf-8"))
    hist = read_history()
    hist.append({"version_str": version, "fingerprint_str": fp, "wrapper_sha256_str": wrapper, "api_version_int": FB.header_api_version(),
                 "released_at_str": time.strftime("%Y-%m-%d %H:%M"),
                 "host_str": FB.host_tag(), "verified_platforms_list": sorted(verified_tags),
                 "algo_commit_str": json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))["source_dict"].get("commit_str", "")})
    HISTORY_PATH.write_text(json.dumps({"schema_str": "fry-sim-release-history/1", "releases_list": hist},
                                       ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    result["release_dir_str"] = str(rel)
    (rel / "release_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    say("\n汇总 → %s" % rel)
    say("  已验证（可交付）：%s" % ("、".join(sorted(verified_tags)) or "无"))
    if result["unverified_kits_list"]:
        say("  待目标机验收：%s（拷到对应机器 → 解压 → sh run_on_target.sh）" % "、".join(result["unverified_kits_list"]))
    return finish(True)


if __name__ == "__main__":
    sys.exit(main())
