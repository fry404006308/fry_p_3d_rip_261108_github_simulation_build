# -*- coding: utf-8 -*-
r"""fry_cross_build.py —— 在一台机器上（Windows 或 Linux）用 zig 交叉编出其它平台的仿真 SDK 二进制。

【先说最重要的一句：交叉编译 ≠ 可交付】
  在 Windows 上编出来的 fry_sim.dylib 是**真正的** Mach-O，但本机跑不了它 ⇒ 不知道它算得对不对。
  仿真 SDK 的承诺是「与 Python 逐位相同」⇒ 交叉产物一律 verified_on_target_bool=false，
  必须拿到目标平台上跑一次 golden（`run_on_target.sh`，或 `fry_build.py --prebuilt-dir`）才变成交付件。
  例外只有一个：**宿主就是目标**（比如在 Linux x64 上交叉编 linux-x64 只是为了把 glibc 基线压到 2.28），
  那就当场跑 golden、当场验证。

【为什么还要交叉编】
  ① Linux：本机 gcc 编出来的库要 glibc 2.38（新系统才有）；zig 能指定 glibc 2.28 基线 ⇒ RHEL 8 / Ubuntu 18.10 起都能加载；
  ② macOS：手边没有 Mac 时，先编出来做接口联调 + 静态闸（格式 / 架构 / 导出面 / 签名 / 装载路径），
     再把「目标机验收包」拷到 Mac 上一条命令验完。

【zig 是什么】一个自带 clang + 各平台 C 库存根的编译器（一个压缩包，不用安装、不用管理员）。
  CMake 只会调「一个可执行文件」，而 zig 的用法是 `zig c++ -target …`（多个词）⇒ 生成一层包装脚本把目标钉死。

用法：
  python tools/fry_cross_build.py --target all --version 1.0.0
  python tools/fry_cross_build.py --target linux-x64,darwin-arm64 --version 1.0.0
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, List

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_binfmt as BF     # noqa: E402
import fry_build as FB      # noqa: E402

OUT = REPO / "out" / "cross"
TOOLCHAIN_DIR_LIST = [Path(r"D:/_300_3D_Rip/_toolchains"), Path.home() / "fry_toolchains"]
GLIBC_STR = "2.28"
TARGET_DICT: Dict[str, Dict[str, str]] = {
    "linux-x64": {"zig_triple": "x86_64-linux-gnu.%s" % GLIBC_STR, "system": "Linux", "proc": "x86_64", "fmt": "ELF", "machine": "x86-64"},
    "linux-arm64": {"zig_triple": "aarch64-linux-gnu.%s" % GLIBC_STR, "system": "Linux", "proc": "aarch64", "fmt": "ELF", "machine": "AArch64"},
    "darwin-arm64": {"zig_triple": "aarch64-macos-none", "system": "Darwin", "proc": "arm64", "fmt": "Mach-O", "machine": "arm64"},
    "darwin-x64": {"zig_triple": "x86_64-macos-none", "system": "Darwin", "proc": "x86_64", "fmt": "Mach-O", "machine": "x86-64"},
}
NINJA_TARGETS = ("fry_sim", "fry_sim_cli", "FrySimDemoC")


def say(text: str) -> None:
    print("  " + text, flush=True)


def find_zig() -> List[str]:
    """zig 怎么调：环境变量 FRY_ZIG_EXE > 工具链目录（加网打包仓已下载过的那份）> PATH > pip 装的 ziglang 包。"""
    env = os.environ.get("FRY_ZIG_EXE", "").strip('"')
    if env and Path(env).is_file():
        return [env]
    for root in TOOLCHAIN_DIR_LIST:
        for cand in sorted(root.glob("zig-*/zig.exe" if os.name == "nt" else "zig-*/zig")):
            return [str(cand)]
    if shutil.which("zig"):
        return [shutil.which("zig")]
    spec = importlib.util.find_spec("ziglang")
    if spec and spec.submodule_search_locations:
        exe = Path(list(spec.submodule_search_locations)[0]) / ("zig.exe" if os.name == "nt" else "zig")
        if exe.is_file():
            return [str(exe)]
    raise SystemExit("✗ 找不到 zig ⇒ ① pip install ziglang==0.16.0 ② 或把 zig 解压到 %s ③ 或设 FRY_ZIG_EXE" % TOOLCHAIN_DIR_LIST[0])


def find_ninja() -> str:
    for root in TOOLCHAIN_DIR_LIST:
        cand = root / "ninja" / ("ninja.exe" if os.name == "nt" else "ninja")
        if cand.is_file():
            return str(cand)
    hit = shutil.which("ninja")
    if hit:
        return hit
    spec = importlib.util.find_spec("ninja")
    if spec:
        import ninja as _n                                      # pip install ninja
        return str(Path(_n.BIN_DIR) / ("ninja.exe" if os.name == "nt" else "ninja"))
    raise SystemExit("✗ 找不到 ninja ⇒ pip install ninja，或放到 %s/ninja/" % TOOLCHAIN_DIR_LIST[0])


def write_toolchain(work: Path, zig: List[str], target: str) -> Path:
    row = TARGET_DICT[target]
    work.mkdir(parents=True, exist_ok=True)
    ext = ".cmd" if os.name == "nt" else ".sh"
    made = {}
    for name, sub in (("cc", "cc"), ("cxx", "c++"), ("ar", "ar"), ("ranlib", "ranlib")):
        p = work / ("zig-%s%s" % (name, ext))
        tgt = (" -target " + row["zig_triple"]) if sub in ("cc", "c++") else ""
        if os.name == "nt":
            p.write_text("@echo off\r\n\"%s\" %s%s %%*\r\n" % ('" "'.join(zig), sub, tgt), encoding="utf-8")
        else:
            p.write_text("#!/bin/sh\nexec \"%s\" %s%s \"$@\"\n" % ('" "'.join(zig), sub, tgt), encoding="utf-8")
            p.chmod(0o755)
        made[name] = str(p).replace("\\", "/")
    strip = '"-Wl,--strip-debug"' if row["fmt"] == "ELF" else '"-Wl,-S"'
    tc = work / "zig-toolchain.cmake"
    tc.write_text("\n".join([
        "# 自动生成：zig 交叉工具链（目标 %s）" % target,
        "set(CMAKE_SYSTEM_NAME %s)" % row["system"], "set(CMAKE_SYSTEM_PROCESSOR %s)" % row["proc"],
        'set(CMAKE_C_COMPILER "%s")' % made["cc"], 'set(CMAKE_CXX_COMPILER "%s")' % made["cxx"],
        'set(CMAKE_AR "%s")' % made["ar"], 'set(CMAKE_RANLIB "%s")' % made["ranlib"],
        "set(FRY_ZIG_CROSS ON)",
        # 链接时剥调试信息 / 调试映射：不泄露构建机路径、同一份源码两次编出来逐字节相同（加网 SDK ★409/★410 实测）
        "set(CMAKE_SHARED_LINKER_FLAGS_INIT %s)" % strip, "set(CMAKE_EXE_LINKER_FLAGS_INIT %s)" % strip,
        "set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)", "set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)",
        "set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)", "set(THREADS_PREFER_PTHREAD_FLAG ON)", ""]),
        encoding="utf-8", newline="\n")
    return tc


def static_problems(target: str, facts: Dict[str, Dict[str, Any]]) -> List[str]:
    """拿到目标机之前就能判死的毛病（格式 / 架构 / 导出面 / rpath / 签名 / 装载路径 / 构建机路径）。"""
    row = TARGET_DICT[target]
    nm = FB.names_of(target)
    probs: List[str] = []
    for key, name in nm.items():
        f = facts.get(name) or {}
        if not f.get("ok_bool"):
            probs.append("%s：缺文件或格式不对（%s）" % (name, f.get("why_str", "没找到")))
            continue
        if f.get("format_str") != row["fmt"] or f.get("machine_str") != row["machine"]:
            probs.append("%s：是 %s %s，目标要 %s %s" % (name, f.get("format_str"), f.get("machine_str"), row["fmt"], row["machine"]))
        bad = [p for p in f.get("rpaths_list", []) if not p.startswith(("$ORIGIN", "@loader_path", "@executable_path"))]
        if bad:
            probs.append("%s：rpath 带构建机路径 %s" % (name, bad))
        if target == "darwin-arm64" and not f.get("codesig_bool"):
            probs.append("%s：arm64 没有代码签名（Apple Silicon 上一启动就被杀）" % name)
        if f.get("stab_count_int"):
            probs.append("%s：带 %d 条调试映射" % (name, f["stab_count_int"]))
        if f.get("host_path_hits_int"):
            probs.append("%s：二进制里有 %d 处构建机路径" % (name, f["host_path_hits_int"]))
    lib = facts.get(nm["lib"]) or {}
    want = FB.header_api_names()
    got = lib.get("exports_list", [])
    extra = [n for n in got if n not in want and not n.startswith(("__dso_handle", "_mh_"))]
    lack = [n for n in want if n not in got]
    if extra or lack:
        probs.append("导出面 ≠ 头文件：少 %s ｜ 多 %s" % (lack, extra[:6]))
    if row["fmt"] == "Mach-O" and lib.get("install_name_str") != "@loader_path/" + nm["lib"]:
        probs.append("install_name 是 %r，应为 @loader_path/%s" % (lib.get("install_name_str"), nm["lib"]))
    for key in ("cli", "demo"):
        f = facts.get(nm[key]) or {}
        if row["fmt"] == "Mach-O":
            if "@loader_path/" + nm["lib"] not in f.get("needed_list", []):
                probs.append("%s：没按 @loader_path/%s 依赖库（%s）" % (nm[key], nm["lib"], f.get("needed_list")))
        elif nm["lib"] not in f.get("needed_list", []) or "$ORIGIN" not in f.get("rpaths_list", []):
            probs.append("%s：要 NEEDED %s + RUNPATH $ORIGIN" % (nm[key], nm["lib"]))
    return probs


RUN_ON_TARGET_SH = """#!/bin/sh
# run_on_target.sh —— 在目标机（%(target)s）上验收这批交叉编译的二进制：真跑 golden，全过才是交付件。
#   有 python3 ⇒ 走完整的「冒烟八条 + 打包」（与 Windows 上出包同一个脚本）；没有 ⇒ 至少跑命令行 selftest。
cd "$(dirname "$0")"
chmod +x prebuilt/fry-sim-cli prebuilt/FrySimDemoC 2>/dev/null
if command -v xattr >/dev/null 2>&1; then xattr -dr com.apple.quarantine . 2>/dev/null; fi
if command -v python3 >/dev/null 2>&1; then
  python3 tools/fry_build.py --version %(version)s --prebuilt-dir prebuilt | tee target_result.txt
else
  ./prebuilt/fry-sim-cli selftest --golden tests/golden | tee target_result.txt
fi
"""
# ★461 不再带 cpp/（算法源码）：验收包要放进公开 GitHub 仓给 macOS / Linux CI 真跑 ⇒ 只带锁文件，
#   fry_build.py 在「--prebuilt-dir 且没有 cpp/」时改走指纹闸（预编件指纹 = 锁 + 库自报指纹 = 锁）
KIT_PARTS = ("tools", "include", "examples", "tests/golden", "cpp.lock.json")


def make_kit(target: str, version: str, pre: Path) -> Path:
    """目标机验收包：二进制 + 冒烟要用的全部东西（脚本 / 头文件 / golden / 锁文件；★461 不带算法源码）。"""
    name = "fry_sim_target_kit-%s-%s" % (version, target)
    zp = OUT / target / (name + ".zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        def put(arc: str, data: bytes, mode: int = 0o644) -> None:
            zi = zipfile.ZipInfo(name + "/" + arc, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = mode << 16
            z.writestr(zi, data)
        for part in KIT_PARTS:
            src = REPO / part
            files = [src] if src.is_file() else sorted(p for p in src.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
            for p in files:
                put(p.relative_to(REPO).as_posix(), p.read_bytes())
        for p in sorted(pre.iterdir()):
            put("prebuilt/" + p.name, p.read_bytes(), 0o755 if p.suffix != ".json" else 0o644)
        put("run_on_target.sh", (RUN_ON_TARGET_SH % {"target": target, "version": version}).encode("utf-8"), 0o755)
    return zp


def build_one(target: str, zig: List[str], ninja: str, version: str) -> Dict[str, Any]:
    row = TARGET_DICT[target]
    work = OUT / target
    if work.exists():
        shutil.rmtree(work)
    build = work / "cmake"
    tc = write_toolchain(work, zig, target)
    cmake = FB.find_cmake() or "cmake"
    t0 = time.time()
    cfg = [cmake, "-S", str(REPO), "-B", str(build), "-G", "Ninja", "-DCMAKE_MAKE_PROGRAM=" + ninja,
           "-DCMAKE_TOOLCHAIN_FILE=" + str(tc), "-DCMAKE_BUILD_TYPE=Release", "-DFRY_SIM_SDK_VERSION=" + version]
    for stage, cmd in (("configure", cfg), ("compile", [ninja, "-C", str(build)] + list(NINJA_TARGETS))):
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            return {"target_str": target, "ok_bool": False, "stage_str": stage, "log_str": (r.stdout + r.stderr)[-3000:]}
    nm = FB.names_of(target)
    pre = work / "prebuilt"
    pre.mkdir(parents=True)
    for v in nm.values():
        shutil.copy2(build / "bin" / v, pre / v)
    facts = {p.name: BF.inspect(p) for p in sorted(pre.iterdir())}
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    zig_ver = subprocess.run(zig + ["version"], capture_output=True, text=True).stdout.strip()
    meta = {"target_str": target, "version_str": version, "zig_triple_str": row["zig_triple"],
            "origin_str": "zig %s 交叉编译（宿主 %s）-target %s" % (zig_ver, FB.host_tag(), row["zig_triple"]),
            "algorithm_fingerprint_str": lock["tree_sha256_str"], "built_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "files_dict": {p.name: FB.sha256_file(p) for p in sorted(pre.iterdir())}}
    (pre / "prebuilt_info.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    probs = static_problems(target, facts)
    kit = make_kit(target, version, pre)
    lib = facts[nm["lib"]]
    return {"target_str": target, "ok_bool": not probs, "stage_str": "done", "seconds_float": round(time.time() - t0, 1),
            "static_problems_list": probs, "prebuilt_dir_str": str(pre), "kit_str": str(kit),
            "lib_dict": {k: lib.get(k) for k in ("format_str", "machine_str", "needed_list", "min_os_str", "codesig_bool",
                                                 "install_name_str", "export_count_int", "size_int", "sha256_str")},
            "verified_on_target_bool": False,
            "verify_note_str": "交叉编译只证明「编得出、格式与导出面对」；逐位 golden 必须在目标平台跑（run_on_target.sh）"}


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="zig 交叉编译仿真 SDK（Linux / macOS）")
    ap.add_argument("--target", default="all", help="linux-x64 / linux-arm64 / darwin-arm64 / darwin-x64 / all（逗号分隔）")
    ap.add_argument("--version", default="0.0.0-dev")
    ap.add_argument("--remake-kits", action="store_true", help="★461 不编译，用已有 prebuilt/ 重打验收包")
    ap.add_argument("--verify-host", action="store_true", help="宿主 == 目标时当场跑 fry_build.py --prebuilt-dir（验收 + 打包）")
    ns = ap.parse_args(argv)
    targets = list(TARGET_DICT) if ns.target == "all" else [t.strip() for t in ns.target.split(",") if t.strip()]
    bad = [t for t in targets if t not in TARGET_DICT]
    if bad:
        raise SystemExit("✗ 不认识的目标 %s（可选 %s）" % (bad, " / ".join(TARGET_DICT)))
    if ns.remake_kits:
        # ★461 不编译：拿 out/cross/<目标>/prebuilt/ 里已有的二进制重打验收包（改了 KIT_PARTS / run_on_target.sh 时用）
        for t in targets:
            pre = OUT / t / "prebuilt"
            info = json.loads((pre / "prebuilt_info.json").read_text(encoding="utf-8"))
            if info.get("version_str") != ns.version:
                raise SystemExit("✗ %s 的预编件版本是 %s，不是 %s" % (t, info.get("version_str"), ns.version))
            print("✓ 重打验收包 %s" % make_kit(t, ns.version, pre))
        return 0
    zig, ninja = find_zig(), find_ninja()
    print("=" * 88)
    print("仿真 SDK 交叉编译 ｜ 版本 %s ｜ 宿主 %s ｜ zig %s" % (ns.version, FB.host_tag(), " ".join(zig)))
    print("=" * 88)
    rows = []
    for t in targets:
        print("── %s（%s）" % (t, TARGET_DICT[t]["zig_triple"]))
        row = build_one(t, zig, ninja, ns.version)
        if row["stage_str"] == "done":
            lib = row["lib_dict"]
            say("%s %s %s ｜ %.2f MB ｜ 导出 %d ｜ 依赖 %s ｜ 最低系统 %s ｜ %.0f s" % (
                "✓" if row["ok_bool"] else "✗", lib["format_str"], lib["machine_str"], lib["size_int"] / 1048576.0,
                lib["export_count_int"], "、".join(lib["needed_list"] or []), lib.get("min_os_str") or "?", row["seconds_float"]))
            for p in row["static_problems_list"]:
                say("  ✗ " + p)
            if ns.verify_host and t == FB.host_tag() and row["ok_bool"]:
                r = subprocess.run([sys.executable, str(REPO / "tools" / "fry_build.py"), "--version", ns.version,
                                    "--prebuilt-dir", row["prebuilt_dir_str"]], capture_output=True, text=True,
                                   encoding="utf-8", errors="replace")
                row["verified_on_target_bool"] = r.returncode == 0
                row["verify_note_str"] = "宿主即目标：当场跑了冒烟八条（含 golden）" + ("，全过" if r.returncode == 0 else "，没过")
                say(("✓ " if r.returncode == 0 else "✗ ") + row["verify_note_str"])
                if r.returncode != 0:
                    print(r.stdout[-2000:] + r.stderr[-1000:])
            if not row["verified_on_target_bool"]:
                say("⚠ 未在目标机验证 ⇒ 验收包 %s" % Path(row["kit_str"]).relative_to(REPO))
        else:
            say("✗ 失败在 %s：\n%s" % (row["stage_str"], row["log_str"]))
        rows.append(row)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "cross_info.json").write_text(json.dumps({"host_str": FB.host_tag(), "version_str": ns.version,
                                                     "targets_list": rows}, ensure_ascii=False, indent=1) + "\n",
                                         encoding="utf-8", newline="\n")
    return 0 if all(r["ok_bool"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
