# -*- coding: utf-8 -*-
r"""fry_payload.py —— 仿真 C++ 载荷（`cpp/`）的同步与校验。

【它解决什么问题】
  仿真 C++ 核心的**唯一真源**是算法仓 `fry_py_260604_c180_depth_dither_more/fry_sim_cpp/`（★450 起）；
  本仓只负责把它编成 dll / so / dylib。两个仓 ⇒ 这里必然是一份**副本**，副本不会自己更新、也不报错 ⇒ 必须配闸：
  · `sync`   从算法仓拷 `fry_sim_cpp/include` 与 `fry_sim_cpp/src` 进 `cpp/`，把每个文件的 sha256、算法仓 commit、
             算法仓 CMakeLists.txt 的 sha256（编译纪律有没有变）写进 `cpp.lock.json`；
  · `check`  重新扫 `cpp/`，与锁文件逐个比 —— 少一个 / 多一个 / 改一个字节都报红（出包第一步）；
  · `status` 算法仓**现在**和上次同步差多少（要不要重新出包）；
  · `info`   打印锁文件摘要。

【换行符】文本文件哈希前 CRLF→LF（同 fry_p_3d_rip_260915_auto_build_dll ★384：同一份代码在 Windows / Linux 检出的指纹相同）。

【tree_sha256】`路径\0sha256\n` 按路径排序拼起来再 sha256 —— 一句话指纹，编进 dll（fry_sim_sdk_fingerprint()），
  拿到一个库就能回答「里面是哪一版仿真算法」。

用法：
  python tools/fry_payload.py sync   --source <算法仓根目录>
  python tools/fry_payload.py check
  python tools/fry_payload.py status --source <算法仓根目录>
  python tools/fry_payload.py info
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
PAYLOAD_DIR = REPO / "cpp"
LOCK_PATH = REPO / "cpp.lock.json"
SCHEMA_STR = "fry-sim-payload-lock/1"
SOURCE_SUBDIR_STR = "fry_sim_cpp"
PAYLOAD_PARTS_TUPLE: Tuple[str, ...] = ("include", "src")      # 只拷算法本体；编译纪律另记 CMakeLists 的指纹
TEXT_EXT_TUPLE: Tuple[str, ...] = (".h", ".hpp", ".c", ".cc", ".cpp", ".inc", ".txt", ".cmake")


def is_text(path: Path) -> bool:
    return path.name == "CMakeLists.txt" or path.suffix.lower() in TEXT_EXT_TUPLE


def normalized_bytes(path: Path) -> bytes:
    data = path.read_bytes()
    return data.replace(b"\r\n", b"\n") if is_text(path) else data


def sha256_of(path: Path) -> str:
    return hashlib.sha256(normalized_bytes(path)).hexdigest()


def files_of(root: Path) -> List[str]:
    """root 下 include/ 与 src/ 里的源码（posix 相对路径，排序 —— 与文件系统遍历顺序无关）。"""
    out: List[str] = []
    for part in PAYLOAD_PARTS_TUPLE:
        base = root / part
        if not base.is_dir():
            continue
        for p in sorted(base.rglob("*")):
            if p.is_file() and is_text(p) and "__pycache__" not in p.parts:
                out.append(p.relative_to(root).as_posix())
    return sorted(out)


def hash_dict(root: Path) -> Dict[str, str]:
    return {rel: sha256_of(root / rel) for rel in files_of(root)}


def tree_sha256(hashes: Dict[str, str]) -> str:
    h = hashlib.sha256()
    for rel in sorted(hashes):
        h.update(("%s\0%s\n" % (rel, hashes[rel])).encode("utf-8"))
    return h.hexdigest()


def _git(repo: Path, *args: str) -> str:
    try:
        r = subprocess.run(["git", "-C", str(repo)] + list(args), capture_output=True, text=True, timeout=30)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def source_dir(algo_repo: Path) -> Path:
    d = Path(algo_repo) / SOURCE_SUBDIR_STR
    if not (d / "include").is_dir() or not (d / "src").is_dir():
        raise SystemExit("✗ 算法仓里找不到 %s/include 与 %s/src：%s" % (SOURCE_SUBDIR_STR, SOURCE_SUBDIR_STR, algo_repo))
    return d


def read_lock() -> Dict[str, Any]:
    if not LOCK_PATH.is_file():
        raise SystemExit("✗ 缺 cpp.lock.json —— 先跑 python tools/fry_payload.py sync --source <算法仓>")
    return json.loads(LOCK_PATH.read_text(encoding="utf-8"))


def diff(want: Dict[str, str], got: Dict[str, str]) -> Dict[str, List[str]]:
    return {"missing_list": sorted(set(want) - set(got)), "extra_list": sorted(set(got) - set(want)),
            "changed_list": sorted(k for k in set(want) & set(got) if want[k] != got[k])}


def sync(algo_repo: Path) -> Dict[str, Any]:
    src = source_dir(algo_repo)
    hashes = hash_dict(src)
    if not hashes:
        raise SystemExit("✗ %s 里没有源码" % src)
    if PAYLOAD_DIR.exists():
        shutil.rmtree(PAYLOAD_DIR)
    for rel in hashes:
        dst = PAYLOAD_DIR / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(normalized_bytes(src / rel))                  # 仓库里只存 LF 一种
    cm = src / "CMakeLists.txt"
    lock = {"schema_str": SCHEMA_STR, "payload_kind_str": "fry_sim_cpp",
            "source_dict": {"path_str": str(Path(algo_repo).resolve()), "subdir_str": SOURCE_SUBDIR_STR,
                            "commit_str": _git(algo_repo, "rev-parse", "HEAD"),
                            "dirty_bool": bool(_git(algo_repo, "status", "--porcelain", "--", SOURCE_SUBDIR_STR)),
                            "algo_cmake_sha256_str": sha256_of(cm) if cm.is_file() else ""},
            "eol_rule_str": "text files: CRLF→LF before sha256",
            "file_count_int": len(hashes), "file_sha256_dict": hashes, "tree_sha256_str": tree_sha256(hashes),
            "synced_at_str": time.strftime("%Y-%m-%d %H:%M:%S")}
    LOCK_PATH.write_text(json.dumps(lock, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    return lock


def check() -> Dict[str, Any]:
    lock = read_lock()
    got = hash_dict(PAYLOAD_DIR)
    d = diff(lock["file_sha256_dict"], got)
    ok = not any(d.values()) and tree_sha256(got) == lock["tree_sha256_str"]
    return dict(d, ok_bool=ok, tree_sha256_str=lock["tree_sha256_str"], file_count_int=len(got))


def status(algo_repo: Path) -> Dict[str, Any]:
    lock = read_lock()
    src = source_dir(algo_repo)
    now = hash_dict(src)
    d = diff(lock["file_sha256_dict"], now)
    cm = src / "CMakeLists.txt"
    cm_now = sha256_of(cm) if cm.is_file() else ""
    cm_changed = bool(lock["source_dict"].get("algo_cmake_sha256_str")) and cm_now != lock["source_dict"]["algo_cmake_sha256_str"]
    return dict(d, up_to_date_bool=not any(d.values()) and not cm_changed, algo_cmake_changed_bool=cm_changed,
                algo_tree_sha256_str=tree_sha256(now), lock_tree_sha256_str=lock["tree_sha256_str"])


def main(argv: Optional[List[str]] = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="仿真 C++ 载荷同步 / 校验")
    ap.add_argument("cmd", choices=["sync", "check", "status", "info"])
    ap.add_argument("--source", default=os.environ.get("FRY_ALGO_REPO", ""))
    a = ap.parse_args(argv)
    if a.cmd in ("sync", "status") and not a.source:
        raise SystemExit("✗ 要 --source <算法仓根目录>（或环境变量 FRY_ALGO_REPO）")
    if a.cmd == "sync":
        lock = sync(Path(a.source))
        print("✓ 同步 %d 个文件 → cpp/ ｜ 指纹 %s ｜ 算法仓 %s%s" % (lock["file_count_int"], lock["tree_sha256_str"][:16],
              lock["source_dict"]["commit_str"][:10] or "(非 git)", "（有未提交改动）" if lock["source_dict"]["dirty_bool"] else ""))
        return 0
    if a.cmd == "check":
        r = check()
        print(("✓ 载荷与锁文件一致（%d 个文件，指纹 %s）" if r["ok_bool"] else "✗ 载荷与锁文件不一致（%d 个文件，指纹 %s）")
              % (r["file_count_int"], r["tree_sha256_str"][:16]))
        for k in ("missing_list", "extra_list", "changed_list"):
            for f in r[k]:
                print("  %s %s" % ({"missing_list": "少", "extra_list": "多", "changed_list": "改"}[k], f))
        return 0 if r["ok_bool"] else 1
    if a.cmd == "status":
        r = status(Path(a.source))
        print("✓ 算法仓与上次同步一致" if r["up_to_date_bool"] else "⚠ 算法仓变了：改 %d / 多 %d / 少 %d%s ⇒ 需要 sync 再出包"
              % (len(r["changed_list"]), len(r["extra_list"]), len(r["missing_list"]),
                 "；算法仓 CMakeLists.txt（编译纪律）也变了" if r["algo_cmake_changed_bool"] else ""))
        return 0
    lock = read_lock()
    print(json.dumps({k: v for k, v in lock.items() if k != "file_sha256_dict"}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
