# -*- coding: utf-8 -*-
r"""fry_build.py —— 在**本机**编出仿真 SDK、冒烟验收、打成包。三平台同一个脚本。

【三步】
  ① 编译：cmake 配置 + 编译（Windows = VS 自带的 MSVC；Linux = gcc / clang；macOS = Apple clang）。
     版本号用 -DFRY_SIM_SDK_VERSION 注进去（源码里不写死）；载荷指纹 CMake 自己读 cpp.lock.json。
  ② 冒烟（smoke）—— 「编得出来」不等于「能用」，下面八条全过才算这一平台的包合格：
     a. 三个产物都在（库 / 命令行 / 纯 C 示例）
     b. 导出面 == 头文件声明（严格相等：少一个调用方链不上，多一个说明内部符号漏出去）
     c. Windows：不依赖 VC++ 运行库 dll（/MT 静态链的证据）；Linux：rpath 只有 $ORIGIN
     d. ctypes 加载：自报版本 == 这次的版本号、自报指纹 == cpp.lock.json、接口版本 == 头文件
     e. fry-sim-cli version 跑得起来
     f. ★ fry-sim-cli selftest：全部 golden 用例（算法仓 Python 算的标准答案）逐位相同，1 线程与多线程都跑
     g. 纯 C 示例跑通（头文件能被 C 编译器包含、结果逐位对）
     h. Python 示例跑通（只用 ctypes）
  ③ 打包：out/package/fry_sim_sdk-<版本>-<平台>/（bin/ include/ golden/ examples/ sdk_info.json VERSION 使用说明）+ 同名 .zip。

【两种来源】
  · 默认：本机编（上面①②③）；
  · --prebuilt-dir <目录>：别处（zig 交叉编）编好的二进制，拿到**目标平台**上只做②③ —— 交叉产物在目标机上真跑过 golden
    才算「验证过」（verified_on_target_bool=true），这是交叉编译产物变成交付件的唯一途径。

用法：
  python tools/fry_build.py --version 1.0.0
  python tools/fry_build.py --version 1.0.0 --prebuilt-dir out/cross/linux-x64/prebuilt
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_binfmt as BF       # noqa: E402

PACKAGE_PREFIX_STR = "fry_sim_sdk"
HEADER_REL_STR = "include/fry_sim_sdk.h"
GOLDEN_DIR = REPO / "tests" / "golden"
LIB_NAME_DICT = {"win32": "fry_sim.dll", "linux": "fry_sim.so", "darwin": "fry_sim.dylib"}
WIN_CMAKE_GLOBS = ("C:/Program Files/CMake/bin/cmake.exe",
                   "C:/Program Files/Microsoft Visual Studio/*/*/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe",
                   "C:/Program Files (x86)/Microsoft Visual Studio/*/*/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+([.-][0-9A-Za-z.-]+)?$")


def say(text: str) -> None:
    print("  " + text, flush=True)


# ───────────────────────────── 平台 / 名字（与算法仓 fry_kernel/sim_cpp.py 同一套叫法） ─────────────────────────────
def host_tag() -> str:
    sysname = {"win32": "win32", "linux": "linux", "darwin": "darwin"}.get(sys.platform, sys.platform)
    mach = platform.machine().lower()
    arch = "x64" if mach in ("amd64", "x86_64") else ("arm64" if mach in ("arm64", "aarch64") else mach)
    return "%s-%s" % (sysname, arch)


def names_of(tag: str) -> Dict[str, str]:
    os_part = tag.split("-")[0]
    exe = ".exe" if os_part == "win32" else ""
    return {"lib": LIB_NAME_DICT[os_part], "cli": "fry-sim-cli" + exe, "demo": "FrySimDemoC" + exe}


def header_api_names(repo: Path = REPO) -> List[str]:
    text = (repo / HEADER_REL_STR).read_text(encoding="utf-8")
    return sorted(set(re.findall(r"FRY_SIM_SDK_API\s+[\w\s\*]+?\b(fry_sim_\w+)\s*\(", text)))


def header_api_version(repo: Path = REPO) -> int:
    m = re.search(r"#define\s+FRY_SIM_SDK_API_VERSION\s+(\d+)", (repo / HEADER_REL_STR).read_text(encoding="utf-8"))
    return int(m.group(1)) if m else -1


def lock_fingerprint(repo: Path = REPO) -> str:
    return json.loads((repo / "cpp.lock.json").read_text(encoding="utf-8"))["tree_sha256_str"]


WRAPPER_PARTS_TUPLE = ("CMakeLists.txt", "include", "src", "packaging")


def wrapper_fingerprint(repo: Path = REPO) -> str:
    """SDK 外壳（不含算法载荷 cpp/）的指纹：头文件 / SDK 源码 / 命令行 / CMake / 导出白名单。
    载荷没变但外壳改了（比如自报信息、编译选项）⇒ 库的字节也变了 ⇒ 版本号也要变（fry_release.next_version 用它）。"""
    import fry_payload
    rows = {}
    for part in WRAPPER_PARTS_TUPLE:
        base = repo / part
        files = [base] if base.is_file() else sorted(p for p in base.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
        for p in files:
            rows[p.relative_to(repo).as_posix()] = hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    return fry_payload.tree_sha256(rows)


def sha256_file(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# ───────────────────────────── ① 编译 ─────────────────────────────
def find_cmake() -> Optional[str]:
    import glob
    env = os.environ.get("FRY_CMAKE", "").strip('"')
    if env and Path(env).is_file():
        return env
    hit = shutil.which("cmake")
    if hit:
        return hit
    exe = "cmake.exe" if sys.platform == "win32" else "cmake"
    for c in (Path(sys.prefix) / "Library" / "bin" / exe, Path(sys.prefix) / "bin" / exe, Path(sys.prefix) / "Scripts" / exe):
        if c.is_file():
            return str(c)
    if sys.platform == "win32":
        for pat in WIN_CMAKE_GLOBS:
            found = sorted(glob.glob(pat), reverse=True)
            if found:
                return found[0]
    return None


def compile_cmds(cmake: str, build: Path, version: str) -> List[List[str]]:
    cfg = [cmake, "-S", str(REPO), "-B", str(build), "-DCMAKE_BUILD_TYPE=Release", "-DFRY_SIM_SDK_VERSION=" + version]
    if sys.platform == "win32":
        cfg += ["-A", "x64"]                          # VS 生成器：64 位（与 64 位 Python 一致）
    elif shutil.which("ninja"):
        cfg += ["-G", "Ninja"]
    return [cfg, [cmake, "--build", str(build), "--config", "Release", "--parallel"]]


def compile_native(version: str) -> Tuple[Path, Dict[str, Any]]:
    cmake = find_cmake()
    if cmake is None:
        raise SystemExit("✗ 找不到 cmake ⇒ ① 装 VS 2022「使用 C++ 的桌面开发」（自带 cmake）② conda install cmake ③ 设 FRY_CMAKE")
    build = REPO / "build" / host_tag()
    if build.exists():
        shutil.rmtree(build)                           # 每次干净编：避免旧缓存里的版本号 / 选项混进来
    t0 = time.time()
    log: List[str] = []
    for cmd in compile_cmds(cmake, build, version):
        say("$ " + " ".join(cmd))
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        log.append(r.stdout + r.stderr)
        if r.returncode != 0:
            print("\n".join(log)[-4000:])
            raise SystemExit("✗ 编译失败（上面是最后 4000 字的日志）")
    return build / "bin", {"origin_str": "本机编译（%s）" % host_tag(), "cmake_str": cmake,
                           "compile_s_float": round(time.time() - t0, 1)}


# ───────────────────────────── ② 冒烟 ─────────────────────────────
def _run(cmd: List[str], cwd: Optional[Path] = None, timeout: int = 600) -> Tuple[int, str]:
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=cwd, timeout=timeout)
    return r.returncode, (r.stdout + r.stderr).strip()


def _ctypes_probe(lib_path: Path) -> Dict[str, Any]:
    """在**子进程**里 ctypes 加载（不让本进程锁住 dll，Windows 上锁住了后面就复制不了 / 删不掉）。"""
    code = ("import ctypes,json,sys;L=ctypes.CDLL(sys.argv[1]);"
            "[setattr(getattr(L,f),'restype',ctypes.c_char_p) for f in ('fry_sim_sdk_version','fry_sim_sdk_fingerprint','fry_sim_sdk_build_info','fry_sim_version')];"
            "print(json.dumps({'version':L.fry_sim_sdk_version().decode(),'fingerprint':L.fry_sim_sdk_fingerprint().decode(),"
            "'build_info':L.fry_sim_sdk_build_info().decode(),'core':L.fry_sim_version().decode(),'api':L.fry_sim_sdk_api_version()}))")
    rc, out = _run([sys.executable, "-c", code, str(lib_path)])
    if rc != 0:
        return {"ok_bool": False, "why_str": out[-800:]}
    return dict(json.loads(out.splitlines()[-1]), ok_bool=True)


def smoke(bin_dir: Path, version: str, tag: str) -> Dict[str, Any]:
    nm = names_of(tag)
    checks: List[Dict[str, Any]] = []

    def add(key: str, ok: bool, detail: str) -> None:
        checks.append({"key_str": key, "ok_bool": bool(ok), "detail_str": detail})
        say("%s %-22s %s" % ("✓" if ok else "✗", key, detail))

    missing = [v for v in nm.values() if not (bin_dir / v).is_file()]
    add("a.产物齐全", not missing, "缺 %s" % missing if missing else "、".join(nm.values()))
    if missing:
        return {"ok_bool": False, "checks_list": checks}
    lib = bin_dir / nm["lib"]
    info = BF.inspect(lib)
    want = header_api_names()
    got = list(info.get("exports_list", []))
    extra = [n for n in got if n not in want and not n.startswith(("__dso_handle", "_mh_"))]
    lack = [n for n in want if n not in got]
    add("b.导出面==头文件", not extra and not lack, "导出 %d 个 / 头文件 %d 个%s%s" % (
        len(got), len(want), "；少 %s" % lack if lack else "", "；多 %s" % extra[:4] if extra else ""))
    if tag.startswith("win32"):
        deps = BF.vc_runtime_deps(info) + BF.vc_runtime_deps(BF.inspect(bin_dir / nm["cli"]))
        add("c.不依赖VC++运行库", not deps, "依赖 %s" % deps if deps else "导入：%s" % "、".join(info["needed_list"]))
    else:
        bad = [p for n in (nm["cli"], nm["demo"]) for p in BF.inspect(bin_dir / n).get("rpaths_list", [])
               if not p.startswith(("$ORIGIN", "@loader_path", "@executable_path"))]
        add("c.rpath只认同目录", not bad, "构建机路径 %s" % bad if bad else "依赖：%s ｜ 最低系统 %s" % (
            "、".join(info.get("needed_list", [])), info.get("min_os_str", "?")))
    pr = _ctypes_probe(lib)
    fp = lock_fingerprint()
    fp_rule = "/fp:precise" if tag.startswith("win32") else "-ffp-contract=off -fno-fast-math"
    ok_d = (pr.get("ok_bool") and pr["version"] == version and pr["fingerprint"] == fp and pr["api"] == header_api_version()
            and fp_rule in pr["build_info"])                      # 浮点纪律是 CMake 注入的**真实**选项，不是抄的一句期望
    add("d.ctypes自报", ok_d, ("版本 %s ｜ 指纹 %s ｜ api %s ｜ %s" % (pr["version"], pr["fingerprint"][:16], pr["api"], pr["build_info"]))
        if pr.get("ok_bool") else pr.get("why_str", ""))
    rc, out = _run([str(bin_dir / nm["cli"]), "version"], cwd=bin_dir)
    add("e.cli version", rc == 0 and fp in out, out.splitlines()[0] if out else "rc=%d" % rc)
    rc, out = _run([str(bin_dir / nm["cli"]), "selftest", "--golden", str(GOLDEN_DIR)], cwd=bin_dir)
    last = out.splitlines()[-1] if out else ""
    add("f.golden逐位", rc == 0 and last.startswith("✓"), last or "rc=%d" % rc)
    selftest_text = out
    rc, out = _run([str(bin_dir / nm["demo"])], cwd=bin_dir)
    add("g.纯C示例", rc == 0, out.splitlines()[-1] if out else "rc=%d" % rc)
    rc, out = _run([sys.executable, str(REPO / "examples" / "python" / "fry_sim_demo.py"), str(lib)])
    add("h.Python示例", rc == 0, out.splitlines()[-1] if out else "rc=%d" % rc)
    return {"ok_bool": all(c["ok_bool"] for c in checks), "checks_list": checks, "probe_dict": pr,
            "selftest_text_str": selftest_text, "lib_inspect_dict": {k: info.get(k) for k in (
                "format_str", "machine_str", "needed_list", "min_os_str", "export_count_int", "size_int", "sha256_str")}}


# ───────────────────────────── ③ 打包 ─────────────────────────────
def package(bin_dir: Path, version: str, tag: str, sm: Dict[str, Any], origin: Dict[str, Any]) -> Path:
    nm = names_of(tag)
    name = "%s-%s-%s" % (PACKAGE_PREFIX_STR, version, tag)
    root = REPO / "out" / "package" / name
    if root.exists():
        shutil.rmtree(root)
    (root / "bin").mkdir(parents=True)
    for k in ("lib", "cli", "demo"):
        shutil.copy2(bin_dir / nm[k], root / "bin" / nm[k])
    if tag.startswith("win32") and (bin_dir.parent / "lib" / "fry_sim.lib").is_file():
        (root / "lib").mkdir()
        shutil.copy2(bin_dir.parent / "lib" / "fry_sim.lib", root / "lib" / "fry_sim.lib")      # MSVC 链接用的导入库
    (root / "include").mkdir()
    shutil.copy2(REPO / HEADER_REL_STR, root / "include" / "fry_sim_sdk.h")
    shutil.copytree(GOLDEN_DIR, root / "golden")
    shutil.copytree(REPO / "examples", root / "examples", ignore=shutil.ignore_patterns("__pycache__"))
    (root / "VERSION").write_text(version + "\n", encoding="utf-8", newline="\n")
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    info = {"schema_str": "fry-sim-sdk-info/1", "package_str": name, "version_str": version, "platform_str": tag,
            "api_version_int": header_api_version(), "library_str": nm["lib"],
            "library_sha256_str": sha256_file(root / "bin" / nm["lib"]),
            "algorithm_fingerprint_str": lock["tree_sha256_str"], "algo_commit_str": lock["source_dict"].get("commit_str", ""),
            "build_info_str": sm.get("probe_dict", {}).get("build_info", ""), "origin_dict": origin,
            "verified_on_target_bool": bool(sm.get("ok_bool")), "verified_on_str": "%s %s" % (platform.system(), platform.machine()),
            "smoke_list": [{k: c[k] for k in ("key_str", "ok_bool", "detail_str")} for c in sm.get("checks_list", [])],
            "built_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "files_dict": {}}
    (root / "使用说明.txt").write_text(USAGE_TXT % {"name": name, "lib": nm["lib"], "cli": nm["cli"]}, encoding="utf-8", newline="\n")
    info["files_dict"] = {p.relative_to(root).as_posix(): sha256_file(p) for p in sorted(root.rglob("*")) if p.is_file()}
    (root / "sdk_info.json").write_text(json.dumps(info, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    zp = root.parent / (name + ".zip")       # ⚠ 不能 with_suffix：版本号里的点会被当成后缀（1.0.0 → 1.0.zip）
    if zp.exists():
        zp.unlink()
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                zi = zipfile.ZipInfo((Path(name) / p.relative_to(root)).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
                zi.compress_type = zipfile.ZIP_DEFLATED
                zi.external_attr = (0o755 if p.parent.name == "bin" else 0o644) << 16   # Linux / macOS 解压后可执行位还在
                z.writestr(zi, p.read_bytes())
    return root


USAGE_TXT = """%(name)s —— 3D 彩色打印模拟仿真计算核心（六视图 / 仿真 GLB）

bin/%(lib)s       动态库（C 接口，头文件 include/fry_sim_sdk.h）
bin/%(cli)s       命令行：version | selftest | bench
golden/           标准答案（算法仓 Python 生产线算的）；selftest 用它逐位比对
examples/c        纯 C 调用示例      examples/python  ctypes 调用示例
sdk_info.json     版本、平台、算法指纹、库的 sha256、冒烟结果（八条）
VERSION           版本号

在这台机器上自检（全绿 = 这个包在这台机器上算得与 Python 逐位相同）：
  Windows : bin\\%(cli)s selftest --golden golden
  Linux / macOS : ./bin/%(cli)s selftest --golden golden
"""


def prebuilt_fingerprint_problem(pinfo: Dict[str, Any], lock: Dict[str, Any]) -> str:
    """★461 验收包不带源码时的「载荷闸」替身（纯函数，与加网仓 ★409 同名同义）：预编件的算法指纹必须 = 锁文件；空串 = 没问题。"""
    got, want = pinfo.get("algorithm_fingerprint_str"), lock.get("tree_sha256_str")
    if not want:
        return "锁文件里没有 tree_sha256_str"
    if got != want:
        return "预编件的算法指纹 %r ≠ 锁文件 %r —— 二进制与这份验收包不是同一次出的" % (got, want)
    return ""


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="本机编译 + 冒烟 + 打包仿真 SDK")
    ap.add_argument("--version", default="0.0.0-dev")
    ap.add_argument("--prebuilt-dir", default="", help="不编译：拿别处编好的二进制在本机冒烟 + 打包（目标机验收）")
    ap.add_argument("--no-package", action="store_true")
    ns = ap.parse_args(argv)
    if not VERSION_RE.match(ns.version):
        raise SystemExit("✗ 版本号要形如 1.2.3（可带 -后缀），收到 %r" % ns.version)
    import fry_payload
    if ns.prebuilt_dir and not fry_payload.PAYLOAD_DIR.is_dir():
        # ★461 验收包不带算法源码（公开 GitHub 仓只放二进制）⇒ 载荷闸改查「预编件记录的指纹 = 锁文件」；
        #   库**自报**的指纹在②冒烟 d 再对一次 ⇒ 二进制的来历仍由两道闸钉住（同加网仓 ★409 的做法）
        pinfo_p = Path(ns.prebuilt_dir).resolve() / "prebuilt_info.json"
        pinfo = json.loads(pinfo_p.read_text(encoding="utf-8")) if pinfo_p.is_file() else {}
        problem = prebuilt_fingerprint_problem(pinfo, json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8")))
        if problem:
            raise SystemExit("✗ " + problem)
        say("⓪ 指纹闸（验收包不带源码）：prebuilt_info.json 的算法指纹 = cpp.lock.json = %s" % lock_fingerprint()[:16])
    else:
        chk = fry_payload.check()
        if not chk["ok_bool"]:
            raise SystemExit("✗ 载荷与 cpp.lock.json 不一致（%s）—— 先 fry_payload.py sync" % {k: v for k, v in chk.items() if v and k.endswith("_list")})
    import fry_make_golden
    g = fry_make_golden.verify_manifest()
    if not g["ok_bool"]:
        raise SystemExit("✗ " + g["why_str"])
    tag = host_tag()
    t0 = time.time()
    print("=" * 88)
    print("仿真 SDK 出包 ｜ 版本 %s ｜ 平台 %s ｜ 载荷指纹 %s" % (ns.version, tag, lock_fingerprint()[:16]))
    print("=" * 88)
    if ns.prebuilt_dir:
        bin_dir = Path(ns.prebuilt_dir).resolve()
        meta_p = bin_dir / "prebuilt_info.json"
        origin = json.loads(meta_p.read_text(encoding="utf-8")) if meta_p.is_file() else {"origin_str": "prebuilt（无说明）"}
        if origin.get("target_str") and origin["target_str"] != tag:
            raise SystemExit("✗ 这批二进制是给 %s 的，本机是 %s —— 要在目标平台上验收" % (origin["target_str"], tag))
        if origin.get("version_str") and origin["version_str"] != ns.version:
            raise SystemExit("✗ 这批二进制编进去的版本是 %s，不是 %s" % (origin["version_str"], ns.version))
        say("① 不编译：用 %s（%s）" % (bin_dir, origin.get("origin_str", "")))
    else:
        say("① 编译")
        bin_dir, origin = compile_native(ns.version)
    say("② 冒烟")
    sm = smoke(bin_dir, ns.version, tag)
    report = {"version_str": ns.version, "platform_str": tag, "smoke_bool": sm["ok_bool"], "smoke_dict": sm,
              "origin_dict": origin, "bin_dir_str": str(bin_dir), "total_s_float": round(time.time() - t0, 1)}
    if sm["ok_bool"] and not ns.no_package:
        root = package(bin_dir, ns.version, tag, sm, origin)
        report["package_str"] = str(root)
        say("③ 打包 → %s（+ .zip）" % root.relative_to(REPO))
    (REPO / "out").mkdir(exist_ok=True)
    (REPO / "out" / ("build_report_%s.json" % tag)).write_text(json.dumps(report, ensure_ascii=False, indent=1) + "\n",
                                                             encoding="utf-8", newline="\n")
    print("%s %s ｜ %.1f s" % ("✓ 出包成功" if sm["ok_bool"] else "✗ 冒烟没过，不出包", tag, report["total_s_float"]))
    return 0 if sm["ok_bool"] else 1


if __name__ == "__main__":
    sys.exit(main())
