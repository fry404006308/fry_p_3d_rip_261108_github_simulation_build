# -*- coding: utf-8 -*-
r"""fry_deliver.py —— 把**出包并冒烟通过**的仿真库交付进算法仓：rip_components/fry_kernel/_bin/fry_sim/<平台>/。

【为什么要交付】算法仓的界面（六视图 / 仿真 GLB 的「仿真引擎 = dll」）要调这个库，库却只在本仓编 ⇒ 算法仓里必有一份**副本**。
  副本不会自己更新、也不报错 ⇒ 每个平台目录旁放一份 sdk_info.json（版本 / 平台 / 算法指纹 / 库的 sha256 / 冒烟结果），
  算法仓加载时：① 现算库的 sha256 与 sdk_info.json 比（手工换了库没更新说明 ⇒ 拒绝加载）；
              ② 库自报的指纹与 sdk_info.json 比；③ 与算法仓 fry_sim_cpp 源码现在的指纹比（源码改了没重新出包 ⇒ 提示）。

【前置条件（不满足就拒绝）】
  · 包的 sdk_info.json 说 verified_on_target_bool = true（在目标平台真跑过 golden）—— 交叉编译没验过的不交付（--allow-unverified 可强行）；
  · 包里的算法指纹 == 算法仓 fry_sim_cpp 现在的指纹（否则交付的是旧算法；--allow-stale 可强行）；
  · 包里记的库 sha256 == 现算（出包后库被换过 ⇒ 拒绝）。
【库被占用时（界面开着）】Windows 不许删正在用的 dll，但允许改名 ⇒ 旧的改名 *.old 让路，新的照常写入；正在跑的软件重启后用上新的。

用法：python tools/fry_deliver.py --algo-repo <算法仓> [--package out/package/fry_sim_sdk-1.0.0-win32-x64] …
      不给 --package ⇒ 交付 out/package/ 里**最新版本号**的所有平台包。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_payload  # noqa: E402

TARGET_REL = Path("rip_components") / "fry_kernel" / "_bin" / "fry_sim"
PACKAGE_DIR = REPO / "out" / "package"


def _ver_key(v: str):
    head = v.split("-")[0]
    return tuple(int(x) for x in head.split(".") if x.isdigit())


def latest_packages() -> List[Path]:
    rows = []
    for d in sorted(PACKAGE_DIR.glob("fry_sim_sdk-*")):
        if d.is_dir() and (d / "sdk_info.json").is_file():
            info = json.loads((d / "sdk_info.json").read_text(encoding="utf-8"))
            rows.append((_ver_key(info["version_str"]), d))
    if not rows:
        return []
    top = max(r[0] for r in rows)
    return [d for k, d in rows if k == top]


def deliver_one(pkg: Path, algo: Path, allow_unverified: bool, allow_stale: bool) -> Dict[str, Any]:
    info = json.loads((pkg / "sdk_info.json").read_text(encoding="utf-8"))
    tag, lib_name = info["platform_str"], info["library_str"]
    row: Dict[str, Any] = {"platform_str": tag, "package_str": pkg.name, "ok_bool": False}
    if not info.get("verified_on_target_bool") and not allow_unverified:
        row["why_str"] = "没在目标平台验过 golden（交叉编译产物）—— 先在目标机跑 run_on_target.sh"
        return row
    src_now = fry_payload.tree_sha256(fry_payload.hash_dict(fry_payload.source_dir(algo)))
    stale = src_now != info["algorithm_fingerprint_str"]
    if stale and not allow_stale:
        row["why_str"] = "包里的算法指纹 %s ≠ 算法仓 fry_sim_cpp 现在的 %s（C++ 改过 ⇒ 先 sync 再出包）" % (
            info["algorithm_fingerprint_str"][:16], src_now[:16])
        return row
    lib = pkg / "bin" / lib_name
    pkg_sha = hashlib.sha256(lib.read_bytes()).hexdigest()
    if pkg_sha != info["library_sha256_str"]:
        row["why_str"] = "包里记的库 sha256 %s ≠ 现算 %s（出包后库被换过）" % (info["library_sha256_str"][:16], pkg_sha[:16])
        return row
    dst = algo / TARGET_REL / tag
    renamed: List[str] = []
    if dst.exists():
        for p in sorted(dst.iterdir()):
            if p.is_dir():
                continue
            try:
                p.unlink()
            except PermissionError:
                if p.name.endswith(".old"):
                    continue
                tgt = p.with_name("%s_被占用_%s.old" % (p.name, time.strftime("%y%m%d_%H%M%S")))
                p.rename(tgt)
                renamed.append(p.name)
    dst.mkdir(parents=True, exist_ok=True)
    shutil.copy2(lib, dst / lib_name)
    shutil.copy2(pkg / "include" / "fry_sim_sdk.h", dst / "fry_sim_sdk.h")
    shutil.copy2(pkg / "VERSION", dst / "VERSION")
    got = hashlib.sha256((dst / lib_name).read_bytes()).hexdigest()
    if got != pkg_sha:
        row["why_str"] = "复制后的库 sha256 %s ≠ 包里 %s（磁盘 / 杀毒软件改了文件？）" % (got[:16], pkg_sha[:16])
        return row
    delivered = {k: v for k, v in info.items() if k != "files_dict"}
    delivered.update(delivered_at_str=time.strftime("%Y-%m-%dT%H:%M:%S%z"), delivered_from_str=pkg.name,
                     source_now_fingerprint_str=src_now, stale_bool=stale, library_sha256_str=got)
    (dst / "sdk_info.json").write_text(json.dumps(delivered, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    row.update(ok_bool=True, dir_str=str(dst), version_str=info["version_str"], sha256_str=got,
               size_int=(dst / lib_name).stat().st_size, renamed_list=renamed, stale_bool=stale,
               verified_bool=bool(info.get("verified_on_target_bool")))
    return row


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="把仿真 SDK 交付进算法仓")
    ap.add_argument("--algo-repo", required=True)
    ap.add_argument("--package", action="append", default=[], help="包目录（可多次）；默认 out/package 里最新版本的全部平台")
    ap.add_argument("--allow-unverified", action="store_true", help="⚠ 没在目标机验过的也交付（只给联调用）")
    ap.add_argument("--allow-stale", action="store_true", help="⚠ 算法指纹与算法仓不一致也交付（只给排障用）")
    ap.add_argument("--result-json", default="")
    ns = ap.parse_args(argv)
    algo = Path(ns.algo_repo).resolve()
    pkgs = [Path(p).resolve() for p in ns.package] or latest_packages()
    if not pkgs:
        print("✗ out/package 里没有包 —— 先跑 python tools/fry_build.py")
        return 1
    rows = [deliver_one(p, algo, ns.allow_unverified, ns.allow_stale) for p in pkgs]
    for r in rows:
        if r["ok_bool"]:
            print("✓ %s → %s（%.2f MB，sha256 %s%s）" % (r["package_str"], Path(r["dir_str"]).relative_to(algo),
                  r["size_int"] / 1048576.0, r["sha256_str"][:16], "，⚠ 未在目标机验证" if not r["verified_bool"] else ""))
            if r["renamed_list"]:
                print("  ⚠ %s 正被占用（界面开着）⇒ 旧文件已改名让路；**正在运行的软件重启后才用上新库**" % "、".join(r["renamed_list"]))
        else:
            print("✗ %s：%s" % (r["package_str"], r["why_str"]))
    if ns.result_json:
        Path(ns.result_json).write_text(json.dumps(rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return 0 if all(r["ok_bool"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
