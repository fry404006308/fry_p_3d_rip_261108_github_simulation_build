# -*- coding: utf-8 -*-
r"""fry_wsl_verify.py —— 在 Windows 上，用 WSL（Windows 自带的真 Linux）验收交叉编出来的 Linux 包。

【为什么】zig 在 Windows 上编出的 fry_sim.so 本机加载不了 ⇒ 不知道它算得对不对；WSL 是真 Linux 内核 + 真 glibc，
  在里面跑一次「目标机验收包」（冒烟八条，含 golden 逐位）就等于在 Linux 上验过 ⇒ 包标 verified_on_target_bool=true。
【做法】把 out/cross/linux-x64/ 里的验收包（zip）在 WSL 的 /tmp 里解开 → sh run_on_target.sh → 把生成的包拷回 out/package/。
  ⚠ 逻辑写成 .sh 再交给 WSL 执行（直接拼进命令行时 `$` 会被提前展开 —— 加网打包仓 ★412 踩过）。

用法：python tools/fry_wsl_verify.py [--target linux-x64]
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]


def to_wsl(p: Path) -> str:
    s = str(Path(p).resolve())
    if len(s) > 1 and s[1] == ":":
        return "/mnt/%s%s" % (s[0].lower(), s[2:].replace("\\", "/"))
    return s.replace("\\", "/")


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="WSL 里验收 Linux 交叉编译产物")
    ap.add_argument("--target", default="linux-x64")
    ns = ap.parse_args(argv)
    if not shutil.which("wsl"):
        print("✗ 本机没有 WSL（wsl --install -d Debian）—— Linux 包只能标「未验证」")
        return 3
    kits = sorted((REPO / "out" / "cross" / ns.target).glob("fry_sim_target_kit-*.zip"))
    if not kits:
        print("✗ 没有 %s 的验收包 —— 先跑 fry_cross_build.py --target %s" % (ns.target, ns.target))
        return 1
    kit = kits[-1]
    sh = REPO / "out" / "cross" / ns.target / "_wsl_verify.sh"
    back = REPO / "out" / "package"
    back.mkdir(parents=True, exist_ok=True)
    lines = ["set -e", "W=/tmp/fry_sim_wsl_verify", 'rm -rf "$W"', 'mkdir -p "$W"', 'cd "$W"',
             'python3 -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall(\'.\')" "%s"' % to_wsl(kit),
             'cd "$W"/fry_sim_target_kit-*', "sh run_on_target.sh",
             'cp -r out/package/. "%s"/' % to_wsl(back)]
    sh.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
    print("$ wsl -- bash %s" % to_wsl(sh), flush=True)
    r = subprocess.run(["wsl", "--", "bash", to_wsl(sh)], capture_output=True)
    out = (r.stdout + r.stderr).decode("utf-8", "replace").replace("\r\n", "\n")
    print(out[-6000:])
    ok = r.returncode == 0 and "✓ 出包成功" in out
    (REPO / "out" / "cross" / ns.target / "wsl_verify.json").write_text(json.dumps(
        {"ok_bool": ok, "rc_int": r.returncode, "kit_str": kit.name, "tail_str": out[-3000:]}, ensure_ascii=False, indent=1),
        encoding="utf-8")
    print(("✓ WSL 里验收通过：%s 已在真 Linux 上跑过 golden，包已拷回 out/package/" if ok else "✗ WSL 验收没过：%s") % ns.target)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
