# -*- coding: utf-8 -*-
r"""fry_binfmt.py —— 纯 Python 读三种二进制格式（ELF / Mach-O / PE），不装任何工具、不需要目标系统。

【为什么要自己读】「这个 .so 真是 Linux x64 的共享库」「这个 .dll 只导出 10 个函数、不依赖 VC++ 运行库」
  这些话要拿证据说；Windows 上没有 readelf / otool，macOS 上没有 dumpbin ⇒ 按格式规范直接读文件头与导出表。
  ELF / Mach-O 两段照搬加网打包仓 tools/fry_cross_build.py（★394 / ★409 / ★410 实测验证过）；PE 段是本仓新写的。

  inspect(path) → {format_str, machine_str, exports_list, needed_list, rpaths_list, min_os_str, size_int, sha256_str, …}
"""
from __future__ import annotations

import hashlib
import re
import struct
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]


def inspect_elf(path: Path) -> Dict[str, Any]:
    """不装任何工具、不跑目标系统，直接按格式规范读 ELF —— 「这真的是一个 Linux 共享库」要拿证据说话。"""
    b = path.read_bytes()
    if b[:4] != b"\x7fELF":
        return {"ok_bool": False, "why_str": "开头不是 ELF 魔数"}
    is64, little = b[4] == 2, b[5] == 1
    end = "<" if little else ">"
    e_type, e_machine = struct.unpack_from(end + "HH", b, 16)
    e_shoff, = struct.unpack_from(end + "Q", b, 0x28)
    e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(end + "HHH", b, 0x3A)
    sections = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size, sh_link, sh_info = struct.unpack_from(end + "IIQQQQII", b, off)
        sh_entsize, = struct.unpack_from(end + "Q", b, off + 56)
        sections.append({"name_off": sh_name, "type": sh_type, "offset": sh_offset, "size": sh_size,
                         "link": sh_link, "entsize": sh_entsize})
    strtab = sections[e_shstrndx]
    names = b[strtab["offset"]: strtab["offset"] + strtab["size"]]

    def sec_name(s):
        e = names.index(b"\0", s["name_off"])
        return names[s["name_off"]:e].decode("utf-8", "replace")

    by_name = {sec_name(s): s for s in sections}
    dynsym, dynstr = by_name.get(".dynsym"), by_name.get(".dynstr")
    exports: List[str] = []
    if dynsym and dynstr:
        sb = b[dynstr["offset"]: dynstr["offset"] + dynstr["size"]]
        n = dynsym["size"] // (dynsym["entsize"] or 24)
        for i in range(n):
            off = dynsym["offset"] + i * dynsym["entsize"]
            st_name, st_info, st_other, st_shndx, st_value, st_size = struct.unpack_from(end + "IBBHQQ", b, off)
            if st_shndx == 0 or not st_name:            # 未定义符号 = 它需要别人提供的，不是它导出的
                continue
            e = sb.index(b"\0", st_name)
            exports.append(sb[st_name:e].decode("utf-8", "replace"))
    needed: List[str] = []
    runpath: List[str] = []
    soname = ""
    dyn = by_name.get(".dynamic")
    if dyn and dynstr:
        sb = b[dynstr["offset"]: dynstr["offset"] + dynstr["size"]]
        for i in range(dyn["size"] // 16):
            tag, val = struct.unpack_from(end + "qQ", b, dyn["offset"] + i * 16)
            if tag == 0:
                break
            if tag in (1, 14, 15, 29):                  # DT_NEEDED / DT_SONAME / DT_RPATH / DT_RUNPATH
                e = sb.index(b"\0", val)
                s = sb[val:e].decode("utf-8", "replace")
                if tag == 1:
                    needed.append(s)
                elif tag == 14:
                    soname = s
                else:
                    runpath.extend(x for x in s.split(":") if x)
    glibc = sorted({tuple(int(x) for x in m.groups() if x) for m in re.finditer(rb"GLIBC_(\d+)\.(\d+)(?:\.(\d+))?", b)})
    return {"ok_bool": True, "format_str": "ELF", "class_str": "64 位" if is64 else "32 位",
            "endian_str": "小端" if little else "大端",
            "type_str": {1: "REL(目标文件)", 2: "EXEC(可执行)", 3: "DYN(共享库/PIE)"}.get(e_type, str(e_type)),
            "machine_str": {0x3E: "x86-64", 0xB7: "AArch64"}.get(e_machine, hex(e_machine)),
            "soname_str": soname, "needed_list": sorted(needed), "rpaths_list": runpath,
            # ★409 最低系统 = 引用到的最高 GLIBC_x.y 符号版本（实测，不是抄配置）
            "min_os_str": ("glibc %s" % ".".join(map(str, glibc[-1]))) if glibc else "",
            "export_count_int": len(exports), "exports_list": sorted(exports),
            "host_path_hits_int": host_path_hits(b),                 # ★410 构建机路径（ELF 靠 --strip-debug 已是 0）
            "size_int": path.stat().st_size, "sha256_str": hashlib.sha256(b).hexdigest()}


def _uleb(b: bytes, i: int) -> Tuple[int, int]:
    r = s = 0
    while True:
        x = b[i]
        i += 1
        r |= (x & 0x7F) << s
        s += 7
        if x < 0x80:
            return r, i


def macho_export_trie(b: bytes, base: int) -> List[str]:
    """★409 dyld 真正查的导出表（export trie）；symtab 里的「外部符号」只是近似（私有外部 N_PEXT 也会混进来）。"""
    out: List[str] = []
    stack = [(0, "")]
    while stack:
        off, prefix = stack.pop()
        i = base + off
        term, i = _uleb(b, i)
        if term:
            out.append(prefix)
            i += term
        nchild = b[i]
        i += 1
        for _ in range(nchild):
            e = b.index(b"\0", i)
            edge = b[i:e].decode("utf-8", "replace")
            child, i = _uleb(b, e + 1)
            stack.append((child, prefix + edge))
    return out


def host_path_hits(b: bytes) -> int:
    """★410 二进制里出现了几处构建机的仓库路径（两种斜杠、不分大小写）：> 0 = 路径泄露，且每台机器编出来都不一样。"""
    low = b.lower()
    return sum(low.count(s.encode("utf-8").lower()) for s in {str(REPO), REPO.as_posix()})


def inspect_macho(path: Path) -> Dict[str, Any]:
    """Mach-O：文件头 + LC_ID_DYLIB + 依赖 + rpath + 最低系统 + 签名 + 导出表（export trie；无 trie 才退回 symtab）。"""
    b = path.read_bytes()
    magic, = struct.unpack_from("<I", b, 0)
    if magic not in (0xFEEDFACF, 0xFEEDFACE):
        return {"ok_bool": False, "why_str": "开头不是 Mach-O 魔数（%s）" % hex(magic)}
    cputype, cpusub, filetype, ncmds, sizeofcmds, flags = struct.unpack_from("<iiIIII", b, 4)
    off = 32 if magic == 0xFEEDFACF else 28
    install_name, sym_exports, dylibs, rpaths = "", [], [], []
    trie: Optional[Tuple[int, int]] = None
    minos = sdk = ""
    codesig = False
    stabs = 0                                            # ★410 调试映射条目（N_STAB：N_SO / N_OSO / N_FUN …）

    def cstr(at: int) -> str:
        return b[at: b.index(b"\0", at)].decode("utf-8", "replace")

    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack_from("<II", b, off)
        if cmd == 0x0D:                                  # LC_ID_DYLIB
            install_name = cstr(off + struct.unpack_from("<I", b, off + 8)[0])
        elif cmd in (0x0C, 0x8000001F, 0x80000018):      # LC_LOAD_DYLIB / LC_LOAD_WEAK_DYLIB / LC_REEXPORT_DYLIB
            dylibs.append(cstr(off + struct.unpack_from("<I", b, off + 8)[0]))
        elif cmd == 0x8000001C:                          # LC_RPATH
            rpaths.append(cstr(off + struct.unpack_from("<I", b, off + 8)[0]))
        elif cmd == 0x1D:                                # LC_CODE_SIGNATURE（arm64 没有它 = 一启动就被内核杀掉）
            codesig = True
        elif cmd == 0x32:                                # LC_BUILD_VERSION
            _plat, v_min, v_sdk = struct.unpack_from("<III", b, off + 8)
            minos = "%d.%d" % (v_min >> 16, (v_min >> 8) & 0xFF)
            sdk = "%d.%d" % (v_sdk >> 16, (v_sdk >> 8) & 0xFF)
        elif cmd == 0x80000022:                          # LC_DYLD_INFO_ONLY（export_off / export_size 在最后两格）
            v = struct.unpack_from("<10I", b, off + 8)
            trie = (v[8], v[9])
        elif cmd == 0x80000033:                          # LC_DYLD_EXPORTS_TRIE
            trie = struct.unpack_from("<II", b, off + 8)
        elif cmd == 0x02:                                # LC_SYMTAB
            symoff, nsyms, stroff, strsize = struct.unpack_from("<IIII", b, off + 8)
            sb = b[stroff: stroff + strsize]
            for i in range(nsyms):
                n_strx, n_type, n_sect, n_desc, n_value = struct.unpack_from("<IBBHQ", b, symoff + i * 16)
                if n_type & 0xE0:                        # N_STAB：调试条目，不是符号
                    stabs += 1
                    continue
                if (n_type & 0x0E) == 0x0E and (n_type & 0x01) and not (n_type & 0x10):   # N_SECT 且 N_EXT、非 N_PEXT
                    e = sb.index(b"\0", n_strx)
                    sym_exports.append(sb[n_strx:e].decode("utf-8", "replace"))
        off += cmdsize
    raw = macho_export_trie(b, trie[0]) if trie and trie[1] else sym_exports
    exports = [n[1:] if n.startswith("_") else n for n in raw]
    return {"ok_bool": True, "format_str": "Mach-O",
            "machine_str": {0x0100000C: "arm64", 0x01000007: "x86-64"}.get(cputype, str(cputype)),
            "type_str": {6: "DYLIB(动态库)", 2: "EXECUTE"}.get(filetype, str(filetype)),
            "install_name_str": install_name, "needed_list": sorted(dylibs), "rpaths_list": rpaths,
            "min_os_str": ("macOS %s" % minos) if minos else "", "sdk_str": sdk, "codesig_bool": codesig,
            "export_source_str": "export trie" if trie and trie[1] else "symtab",
            "export_count_int": len(exports), "exports_list": sorted(exports),
            "stab_count_int": stabs, "host_path_hits_int": host_path_hits(b),
            "size_int": path.stat().st_size, "sha256_str": hashlib.sha256(b).hexdigest()}


def inspect_pe(path: Path) -> Dict[str, Any]:
    """PE（Windows dll / exe）：机器类型 + 导出名表 + 导入的 dll 名（看得出有没有依赖 VC++ 运行库 vcruntime / msvcp）。"""
    b = path.read_bytes()
    if b[:2] != b"MZ":
        return {"ok_bool": False, "why_str": "开头不是 MZ"}
    pe_off, = struct.unpack_from("<I", b, 0x3C)
    if b[pe_off:pe_off + 4] != b"PE\0\0":
        return {"ok_bool": False, "why_str": "没有 PE 签名"}
    machine, nsec = struct.unpack_from("<HH", b, pe_off + 4)
    opt_size, chars = struct.unpack_from("<HH", b, pe_off + 20)
    opt = pe_off + 24
    magic, = struct.unpack_from("<H", b, opt)
    dd = opt + (112 if magic == 0x20B else 96)
    secs = []
    for i in range(nsec):
        s = opt + opt_size + 40 * i
        vsize, vaddr, rsize, rptr = struct.unpack_from("<IIII", b, s + 8)
        secs.append((vaddr, max(vsize, rsize), rptr))

    def off(rva: int) -> int:
        for va, size, ptr in secs:
            if va <= rva < va + size:
                return rva - va + ptr
        raise ValueError("RVA %x 不在任何节里" % rva)

    def cstr(at: int) -> str:
        return b[at: b.index(b"\0", at)].decode("utf-8", "replace")

    exports: List[str] = []
    exp_rva, exp_size = struct.unpack_from("<II", b, dd)
    if exp_rva:
        e = off(exp_rva)
        n_names, = struct.unpack_from("<I", b, e + 24)
        names_rva, = struct.unpack_from("<I", b, e + 32)
        for i in range(n_names):
            exports.append(cstr(off(struct.unpack_from("<I", b, off(names_rva) + 4 * i)[0])))
    imports: List[str] = []
    imp_rva, _imp_size = struct.unpack_from("<II", b, dd + 8)
    if imp_rva:
        p = off(imp_rva)
        while True:
            name_rva, = struct.unpack_from("<I", b, p + 12)
            if not name_rva:
                break
            imports.append(cstr(off(name_rva)))
            p += 20
    return {"ok_bool": True, "format_str": "PE", "machine_str": {0x8664: "x86-64", 0xAA64: "arm64", 0x14C: "x86"}.get(machine, hex(machine)),
            "type_str": "DLL" if chars & 0x2000 else "EXE", "needed_list": sorted(imports, key=str.lower), "rpaths_list": [],
            "min_os_str": "", "export_count_int": len(exports), "exports_list": sorted(exports),
            "host_path_hits_int": host_path_hits(b), "size_int": path.stat().st_size, "sha256_str": hashlib.sha256(b).hexdigest()}


def inspect(path: Path) -> Dict[str, Any]:
    """按文件头自动认格式。"""
    head = Path(path).read_bytes()[:4]
    if head == b"\x7fELF":
        return inspect_elf(Path(path))
    if head[:2] == b"MZ":
        return inspect_pe(Path(path))
    return inspect_macho(Path(path))


VC_RUNTIME_RE = re.compile(r"^(vcruntime|msvcp|concrt|vcomp)\d*.*\.dll$", re.I)


def vc_runtime_deps(info: Dict[str, Any]) -> List[str]:
    """依赖了哪些 VC++ 运行库 dll（/MT 静态链之后应为空 ⇒ 目标机不用装 VC++ Redistributable）。"""
    return [n for n in info.get("needed_list", []) if VC_RUNTIME_RE.match(n)]
