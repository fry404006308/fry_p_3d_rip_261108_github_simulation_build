# -*- coding: utf-8 -*-
r"""fry_make_golden.py —— 用**算法仓的 Python 生产线**算出仿真核心的「标准答案」（golden），写进 tests/golden/。

【为什么标准答案必须来自 Python、不能来自 C++ 自己】
  C++ 核心的承诺是「与 Python 逐位相同」。如果用 C++ 的输出当答案，再拿 C++ 去比，永远是绿的（自己考自己）。
  ⇒ 每个用例的期望值都由算法仓里**真正在用**的 Python 代码算：
     ① gaussian3d          ← scipy.ndimage.gaussian_filter（六视图法线就是用它平滑的）
     ② normal_fields       ← SC100_kubelka_munk._normal_fields_shared（六视图共用法线场的 Python 实现）
     ③ normal_sample_fold  ← SC100 `_sample_rows_offs` 的下标算式（逐字照抄）+ fry_kernel.optics_column._fold_chunk（生产叠加）
     ④ ray_columns_fold    ← SF200_mesh_common.normal_ray_columns（材料柱）+ _fold_chunk（叠加）
     ⑤ ★458 run_jobs（整条流程）← 算法仓 HB100 / EB100 门面以 python 引擎跑同一叠 BMP：六视图 PNG 用 PIL 解码成像素 .raw、
        view_frames.json 原样、仿真 GLB 原字节；两份作业单是 cpp 引擎门面**自己拼的**（截下来，不调库）。
  其中 ③ 另外用 450 测试里的独立参照式再算一遍、两者必须逐位相同，才写盘（参照式自己也被交叉验证）。

【写出什么】tests/golden/<用例>/case.txt（func=… 与标量参数，threads=1,3 表示两种线程数都要跑）+ 若干 .npy；
  tests/golden/golden.json：每个文件的 sha256、生成它的算法仓 commit、对应的载荷指纹（cpp.lock.json）。
  ⇒ 载荷一换（重新 sync），fry_release.py 会发现指纹对不上、要求重新生成 golden，不会拿旧答案考新代码。

用法：python tools/fry_make_golden.py --source <算法仓根目录>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict

try:
    import numpy as np
except ImportError:          # 目标机验收（run_on_target.sh）只调 verify_manifest：没装 numpy 的机器也要能验
    np = None

REPO = Path(__file__).resolve().parents[1]
GOLDEN_DIR = REPO / "tests" / "golden"
SCHEMA_STR = "fry-sim-golden/1"


def _setup_algo(algo: Path):
    rc = algo / "rip_components"
    for p in (str(rc), str(algo), str(rc / "_tests")):
        if p not in sys.path:
            sys.path.insert(0, p)
    import ZC100_paths                                         # noqa: F401  算法仓自己的路径约定
    ZC100_paths.setup()


def _save(case: Path, func: str, arrays: Dict[str, np.ndarray], **scalars: Any) -> None:
    case.mkdir(parents=True, exist_ok=True)
    lines = ["func=%s" % func] + ["%s=%s" % (k, v) for k, v in scalars.items()]
    (case / "case.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    for k, a in arrays.items():
        np.save(case / (k + ".npy"), np.ascontiguousarray(a), allow_pickle=False)


def _blob(seed=0, shape=(37, 29, 61)):
    """不对称实心团（同 450 测试）：外壳 6、里面随机墨、核心 5、再挖一道空气缝 —— 法线、出界、空列都走得到。"""
    rng = np.random.default_rng(seed)
    z, y, x = np.meshgrid(*[np.linspace(-1, 1, n) for n in shape], indexing="ij")
    r = np.sqrt((z - 0.15) ** 2 + (1.3 * y) ** 2 + (x + 0.2) ** 2) + 0.15 * x * y
    v = np.zeros(shape, np.uint8)
    v[r < 0.95] = 6
    v[r < 0.85] = rng.choice([1, 2, 3, 5], size=v[r < 0.85].shape)
    v[r < 0.55] = 5
    v[(np.abs(x - 0.4) < 0.08) & (r < 0.85)] = 0
    return v


def _tables():
    rng = np.random.default_rng(7)
    Rl = rng.uniform(0.0, 0.6, (8, 3)).astype(np.float32)
    T2 = rng.uniform(0.2, 0.95, (8, 3)).astype(np.float32)
    R0 = np.array([0.91, 0.88, 0.86], np.float32)
    plut = np.zeros(256, np.uint8)
    plut[[1, 2, 3, 4, 5]] = 1
    return Rl, T2, R0, plut


def _fold(cols2d: np.ndarray, Rl, T2, R0, plut) -> np.ndarray:
    from fry_kernel import optics_column as OC
    R2 = np.empty((cols2d.shape[0], 3), np.float32)
    R2[:] = R0
    OC._fold_chunk(np.ascontiguousarray(cols2d), Rl, T2, plut.astype(bool), R2)
    return R2


def _sample_seq(v, hit, first, n0, n1, n2, t, mm, offs, null=0):
    """SC100 `_sample_rows_offs` 的下标算式（整张视图一批）。返回每个偏移的 [d0,d1,S] 材料序列。"""
    d0, d1, L = v.shape
    rr = np.arange(d0)[:, None]
    cc = np.arange(d1)[None, :]
    B0 = n0[:, :, None] * t / mm[0]
    B1 = n1[:, :, None] * t / mm[1]
    i2raw = np.round(first[:, :, None] + n2[:, :, None] * t / mm[2])
    inb = (i2raw >= 0) & (i2raw <= L - 1)
    i2 = np.clip(i2raw, 0, L - 1).astype(np.int64)
    out = []
    for offr, offc in offs:
        i0 = np.clip(np.round(rr[..., None] + offr + B0), 0, d0 - 1).astype(np.int64)
        i1 = np.clip(np.round(cc[..., None] + offc + B1), 0, d1 - 1).astype(np.int64)
        seq = np.where(inb, v[i0, i1, i2], np.uint8(null))
        out.append(np.where(hit[:, :, None], seq, np.uint8(null)))
    return out


def _ref_fold_450(seq, Rl, T2, R0, plut):
    """450 测试里的独立参照式（逐层 numpy，不排序）—— 用来交叉验证 _fold_chunk 路。"""
    d0, d1, _ = seq.shape
    R = np.empty((d0, d1, 3), np.float32)
    R[:] = R0
    for l in range(seq.shape[-1] - 1, -1, -1):
        ink = seq[:, :, l]
        act = plut[ink].astype(bool)
        Rn = Rl[ink] + (T2[ink] * R) / (1.0 - Rl[ink] * R + 1e-6)
        R = np.where(act[..., None], np.clip(Rn, 0.0, 1.0), R)
    return R


def make(algo: Path) -> Dict[str, Any]:
    _setup_algo(algo)
    from scipy import ndimage
    from fry_kernel import sim_cpp as SCP
    from S200_Simulation.HB100_optics_sim._inner import SC100_kubelka_munk as SC

    if GOLDEN_DIR.exists():
        shutil.rmtree(GOLDEN_DIR)
    rng = np.random.default_rng(456)

    # ① 高斯：三种形状；含「核比轴长」（reflect 折返多次）与「σ=0 跳过该轴」
    for name, shape, sig in (("gauss_a_long_kernel", (23, 31, 57), (1.46, 5.7, 20.0)),
                             ("gauss_b_skip_axis", (5, 200, 7), (20.0, 0.0, 3.0)),
                             ("gauss_c_tiny", (3, 4, 2), (5.0, 5.0, 5.0))):
        a = (rng.random(shape) > 0.5).astype(np.float32)
        w = [SCP.gauss_weights(s) for s in sig]
        _save(GOLDEN_DIR / name, "gaussian3d", {"in": a, "w0": w[0], "w1": w[1], "w2": w[2],
                                                 "expect": ndimage.gaussian_filter(a, sig)}, threads="1,3")

    # ② 法线场：8 种翻转 × 两种轴序 × 含 / 不含透明
    vol = _blob()
    sig = (1.46, 5.7, 3.0)
    flips = [(a, b, c) for a in (0, 1) for b in (0, 1) for c in (0, 1)]
    lut = SC._SUBST_LUT.astype(np.uint8)
    for name, axes, incl in (("normal_fields_axes012_incl", (0, 1, 2), True), ("normal_fields_axes201_excl", (2, 0, 1), False)):
        can = np.ascontiguousarray(np.transpose(vol, axes))
        ref = SC._normal_fields_shared(can, sig, flips, 1, max_vox=1500, include_transparent=incl)
        w = [SCP.gauss_weights(s) for s in sig]
        arr = {"can": can, "lut": lut, "w0": w[0], "w1": w[1], "w2": w[2], "flips": np.asarray(flips, np.uint8)}
        for k, j in (("hit", 0), ("first", 1), ("g0", 2), ("g1", 3), ("g2", 4)):
            st = np.stack([r[j] for r in ref])
            arr["expect_" + k] = st.astype(np.uint8) if k == "hit" else st
        _save(GOLDEN_DIR / name, "normal_fields", arr, transparent_code=6, include_transparent=int(incl), max_vox=1500,
              threads="1,3")

    # ③ 六视图采样 + 叠加：带翻转的视图、真实算出来的法线、5 个侧向偏移
    Rl, T2, R0, plut = _tables()
    for name, seed in (("normal_sample_fold_seed1", 1), ("normal_sample_fold_seed2", 2)):
        v = np.ascontiguousarray(_blob(seed)[:, ::-1, :])
        hit, first, g0, g1, g2 = SC._normal_field_lean(v, (1.46, 5.7, 3.0), include_transparent=True)
        mm = (0.137, 0.035, 0.010)
        n0, n1, n2 = g0 / mm[0], g1 / mm[1], g2 / mm[2]
        nrm = np.sqrt(n0 * n0 + n1 * n1 + n2 * n2)
        bad = nrm < 1e-8
        n0 = np.where(bad, 0.0, n0 / np.maximum(nrm, 1e-8)).astype(np.float32)
        n1 = np.where(bad, 0.0, n1 / np.maximum(nrm, 1e-8)).astype(np.float32)
        n2 = np.where(bad, 1.0, n2 / np.maximum(nrm, 1e-8)).astype(np.float32)
        t = (np.arange(41, dtype=np.float32) * 0.02)[None, None, :]
        offs = [(0.0, 0.0)] + [(0.7 * np.cos(a), 0.7 * np.sin(a)) for a in (0.0, np.pi / 2, np.pi, 1.5 * np.pi)]
        mm32 = tuple(np.float32(m) for m in mm)
        seqs = _sample_seq(v, hit, first, n0, n1, n2, t, mm32, offs)
        d0, d1 = v.shape[:2]
        exp = np.stack([_fold(s.reshape(-1, s.shape[-1]), Rl, T2, R0, plut).reshape(d0, d1, 3) for s in seqs])
        alt = np.stack([_ref_fold_450(s, Rl, T2, R0, plut) for s in seqs])
        if not np.array_equal(exp.view(np.uint32), alt.view(np.uint32)):
            raise SystemExit("✗ %s：_fold_chunk 与 450 参照式不逐位相同 —— 参照本身有问题，不写 golden" % name)
        _save(GOLDEN_DIR / name, "normal_sample_fold",
              {"v": v, "n0": n0, "n1": n1, "n2": n2, "first": first.astype(np.int64), "hit": hit.astype(np.uint8),
               "t": np.ravel(t), "offs": np.asarray(offs, np.float64), "part_lut": plut, "Rl": Rl, "T2": T2, "R0": R0,
               "expect": exp},
              mm_r=repr(float(mm32[0])), mm_c=repr(float(mm32[1])), mm_v=repr(float(mm32[2])), null_code=0, threads="1,4")

    # ④ 仿真 GLB 的足迹射线：各向异性体素、随机方向（含射出体外 / 全空气 / 贴边）
    from S200_Simulation.EB100_sim_glb._inner import SF200_mesh_common as C
    from S200_Simulation.EB100_sim_glb._inner import _cfg
    from S200_Simulation.EB100_sim_glb._inner._defaults import DEFAULT_PARAM_DICT as P
    from fry_kernel import materials as MAT
    rng2 = np.random.default_rng(450)
    vox = (0.137, 0.035, 0.010)
    vol = rng2.choice([0, 1, 2, 3, 5, 6, 7], size=(20, 60, 200), p=[.3, .1, .1, .1, .2, .1, .1]).astype(np.uint8)
    ext = np.array([20 * vox[0], 60 * vox[1], 200 * vox[2]])
    pts = rng2.uniform(-0.2, 1.2, (3000, 3)) * ext
    nrm = rng2.normal(size=(3000, 3))
    nrm /= np.linalg.norm(nrm, axis=1, keepdims=True)
    win, step = 0.8, 0.010
    with _cfg.env.bind(dict(P, MATERIAL_PRESET="gt407")) as cfg:
        MAT.apply("gt407", cfg, verbose=False)
        cols = C.normal_ray_columns(vol, vox, pts, nrm, win, step)
    vm = np.asarray(vox)
    nt = int(np.ceil((win + 2.0 * vm.max()) / step))
    ts = np.arange(nt) * step - float(vm.max())
    solid = np.zeros(256, np.uint8)
    solid[[1, 2, 3, 4, 5, 6]] = 1
    _save(GOLDEN_DIR / "ray_columns_fold_aniso", "ray_columns_fold",
          {"vol": vol, "vm": vm.astype(np.float64), "pts": pts, "nrm": nrm, "ts": ts, "solid_lut": solid, "part_lut": plut,
           "Rl": Rl, "T2": T2, "R0": R0, "expect_cols": cols.astype(np.uint8), "expect_rgb": _fold(cols, Rl, T2, R0, plut)},
          nwin=int(round(win / step)), null_code=0, threads="1,3")

    make_folder_case(GOLDEN_DIR / "folder_ball")
    return write_manifest(algo)


THREADS_TOKEN_STR = "${THREADS}"


def _raw(png: Path, dst: Path) -> None:
    """Python（PIL）解码出的像素 → .raw（宽 高 通道 三个 int32 小端 + 像素），与 C++ 作业单 raw_pixels_bool 写的格式一样。"""
    from PIL import Image
    with Image.open(png) as im:
        a = np.ascontiguousarray(np.asarray(im))
    h, w = a.shape[:2]
    c = 1 if a.ndim == 2 else a.shape[2]
    dst.write_bytes(np.asarray([w, h, c], "<i4").tobytes() + a.tobytes())


def _capture_job(run, patches) -> Dict[str, Any]:
    """跑一次 cpp 引擎的门面，但把交给 C++ 的作业单**截下来**（不调库）：作业单就是生产线自己拼的那一份，不是测试另抄的。"""
    from fry_kernel import sim_cpp as SCP
    got: Dict[str, Any] = {}

    class _Captured(Exception):
        pass

    def _fake_run_job(lib, job):
        got.update(json.loads(json.dumps(job)))
        raise _Captured()

    saved = [(m, k, getattr(m, k)) for m, k, _v in patches] + [(SCP, "run_job", SCP.run_job), (SCP, "has_run_job", SCP.has_run_job)]
    try:
        for m, k, v in patches:
            setattr(m, k, v)
        SCP.run_job = _fake_run_job
        SCP.has_run_job = lambda lib: True
        run()
    except Exception:
        pass
    finally:
        for m, k, v in saved:
            setattr(m, k, v)
    if not got:
        raise SystemExit("✗ 没截到作业单（整条流程没走到？）")
    return got


def make_folder_case(case: Path) -> None:
    """★458 整条流程 golden：一叠真 BMP（算法仓测试链出片）+ 两份作业单（生产线自己拼的）+ Python 引擎跑出来的标准答案
    （六视图：PIL 解码后的像素 .raw + view_frames.json；仿真 GLB：trimesh 导出的 .glb 原字节）。命令行 selftest 逐个比。"""
    import importlib
    import fixture_chain as FX
    case.mkdir(parents=True, exist_ok=True)
    src = Path(FX.stage("bmp")["output_data"])
    shutil.copytree(src, case / "bmp")
    bmp = case / "bmp"
    p6 = {"SIM_PPM": 30.0, "MATERIAL_PRESET": "gt407", "KM_SIM_COLUMN_MODE": "normal", "KM_COLOR_PATH_CLAMP": False,
          "KM_NORMAL_DENOISE": "supersample", "KM_NORMAL_GEOMETRY_MODE": "occupancy", "SIM_THREADS": 1}
    pg = {"SIM_GLB_METHOD": "marching_cubes", "SIM_GLB_COLOR_POOL": "footprint", "SIM_GLB_COLUMN_OPTICS": "ray_color",
          "SIM_GLB_FOOTPRINT_RAYS": 32, "SIM_GLB_COLOR_CHUNK": 20, "MATERIAL_PRESET": "gt407", "KM_COLOR_PATH_CLAMP": False,
          "SIM_THREADS": 1}
    work = Path(FX.work_dir()) / "golden458"
    if work.exists():
        shutil.rmtree(work)
    SC = importlib.import_module("HB100_optics_sim._inner.SC100_kubelka_munk")
    C = importlib.import_module("EB100_sim_glb._inner.SF200_mesh_common")

    def _hb(engine, out):
        return FX.facade("HB100_optics_sim").fry_run({"input_data": str(bmp), "out_dir_str": str(out), "band_capacity_mm": 0.8,
                                                       "param_dict": dict(p6, SIM_ENGINE=engine)})

    def _eb(engine, out):
        return FX.facade("EB100_sim_glb").fry_run({"input_data": str(bmp), "name_str": "ball", "out_dir_str": str(out),
                                                    "band_capacity_mm": 0.8, "param_dict": dict(pg, SIM_ENGINE=engine)})

    job6 = _capture_job(lambda: _hb("cpp", work / "cap6"), [(SC, "_cpp_lib", lambda opt: "LIB")])
    jobg = _capture_job(lambda: _eb("cpp", work / "capg"), [(C, "_cpp_lib_or_reason", lambda: ("LIB", "golden"))])
    r6 = _hb("python", work / "py6")
    rg = _eb("python", work / "pyg")
    if not (r6.is_success and rg.is_success):
        raise SystemExit("✗ Python 参照没跑成：%s / %s" % (r6.message_str, rg.message_str))
    exp6 = case / "expect_six"
    exp6.mkdir()
    out6 = Path(r6.data_dict["output_data"])
    for png in sorted(out6.glob("*.png")):
        _raw(png, exp6 / (png.stem + ".raw"))
    shutil.copyfile(out6 / "view_frames.json", exp6 / "view_frames.json")
    (case / "expect_glb").mkdir()
    shutil.copyfile(rg.data_dict["output_data"], case / "expect_glb" / "ball.glb")
    job6.update(input_dir_str="${CASE}/bmp", output_dir_str="${OUT}/six", raw_pixels_bool=True)
    jobg.update(input_dir_str="${CASE}/bmp", output_glb_str="${OUT}/glb/ball.glb")
    for name, job in (("job_six_view.json", job6), ("job_sim_glb.json", jobg)):
        job["threads_int"] = 1
        txt = json.dumps(job, ensure_ascii=False, indent=1).replace('"threads_int": 1', '"threads_int": ' + THREADS_TOKEN_STR)
        (case / name).write_text(txt + "\n", encoding="utf-8", newline="\n")
    import fry_build as FB                      # ★458 记下答案是哪个平台的 Python 算的：同平台逐字节，别的平台按 C 库末位差放宽（命令行里写明）
    (case / "case.txt").write_text("func=run_jobs\njobs=job_six_view.json,job_sim_glb.json\nthreads=1,3\nplatform=%s\n" % FB.host_tag(),
                                   encoding="utf-8", newline="\n")


def _git(repo: Path, *args: str) -> str:
    try:
        r = subprocess.run(["git", "-C", str(repo)] + list(args), capture_output=True, text=True, timeout=30)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def write_manifest(algo: Path) -> Dict[str, Any]:
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    cases = {}
    for d in sorted(p for p in GOLDEN_DIR.iterdir() if p.is_dir()):
        kv = dict(l.split("=", 1) for l in (d / "case.txt").read_text(encoding="utf-8").splitlines() if "=" in l)
        cases[d.name] = {"func_str": kv["func"],          # ★458 整条流程用例有子目录（bmp/、expect_*/）⇒ 递归、记相对路径
                         "file_sha256_dict": {f.relative_to(d).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
                                              for f in sorted(d.rglob("*")) if f.is_file()}}
    man = {"schema_str": SCHEMA_STR, "payload_tree_sha256_str": lock["tree_sha256_str"],
           "algo_commit_str": _git(algo, "rev-parse", "HEAD"), "numpy_str": np.__version__,
           "generated_at_str": time.strftime("%Y-%m-%d %H:%M:%S"), "case_count_int": len(cases), "case_dict": cases}
    (GOLDEN_DIR / "golden.json").write_text(json.dumps(man, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    return man


def verify_manifest() -> Dict[str, Any]:
    """golden 没被改过、且与当前载荷配套：出包第二步（fry_release.py 调）。"""
    p = GOLDEN_DIR / "golden.json"
    if not p.is_file():
        return {"ok_bool": False, "why_str": "缺 tests/golden/golden.json —— 先跑 fry_make_golden.py --source <算法仓>"}
    man = json.loads(p.read_text(encoding="utf-8"))
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    if man["payload_tree_sha256_str"] != lock["tree_sha256_str"]:
        return {"ok_bool": False, "why_str": "golden 是给载荷 %s 生成的，现在载荷是 %s ⇒ 重新生成 golden"
                % (man["payload_tree_sha256_str"][:16], lock["tree_sha256_str"][:16])}
    for name, c in man["case_dict"].items():
        for f, h in c["file_sha256_dict"].items():
            fp = GOLDEN_DIR / name / f
            if not fp.is_file() or hashlib.sha256(fp.read_bytes()).hexdigest() != h:
                return {"ok_bool": False, "why_str": "golden 文件被改 / 缺：%s/%s" % (name, f)}
    return {"ok_bool": True, "why_str": "", "case_count_int": man["case_count_int"]}


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="用算法仓 Python 生产线生成仿真核心 golden")
    ap.add_argument("--source", default=os.environ.get("FRY_ALGO_REPO", ""))
    ap.add_argument("--verify", action="store_true", help="只校验 golden 完整且与当前载荷配套")
    a = ap.parse_args(argv)
    if a.verify:
        r = verify_manifest()
        print("✓ golden 完整（%d 个用例）且与载荷配套" % r["case_count_int"] if r["ok_bool"] else "✗ " + r["why_str"])
        return 0 if r["ok_bool"] else 1
    if not a.source:
        raise SystemExit("✗ 要 --source <算法仓根目录>（或环境变量 FRY_ALGO_REPO）")
    man = make(Path(a.source).resolve())
    size = sum(f.stat().st_size for f in GOLDEN_DIR.rglob("*") if f.is_file())
    print("✓ golden：%d 个用例，%.1f MB ｜ 载荷指纹 %s ｜ 算法仓 %s" % (man["case_count_int"], size / 1e6,
          man["payload_tree_sha256_str"][:16], man["algo_commit_str"][:10] or "(非 git)"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
