# -*- coding: utf-8 -*-
r"""examples/python/fry_sim_demo.py —— Python 消费方示例：只用标准库 ctypes（不需要 numpy）加载 fry_sim，调一次高斯平滑。

  python fry_sim_demo.py [库的路径]      # 不给路径 ⇒ 按 SDK 包布局找 ../../bin/fry_sim.*

例子与纯 C 示例相同：1×1×5 的脉冲 [0,0,1,0,0] 用 [0.25,0.5,0.25] 沿最后一轴平滑 ⇒ [0,0.25,0.5,0.25,0]（逐位精确）。
"""
import ctypes
import sys
from pathlib import Path

LIB_NAME = {"win32": "fry_sim.dll", "darwin": "fry_sim.dylib"}.get(sys.platform, "fry_sim.so")


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "bin" / LIB_NAME
    lib = ctypes.CDLL(str(path))
    for f in ("fry_sim_sdk_version", "fry_sim_sdk_fingerprint", "fry_sim_sdk_build_info", "fry_sim_version", "fry_sim_last_error"):
        getattr(lib, f).restype = ctypes.c_char_p
    lib.fry_sim_sdk_api_version.restype = ctypes.c_int
    P, I64 = ctypes.c_void_p, ctypes.c_int64
    lib.fry_sim_gaussian3d.argtypes = [P, P, P, I64, P, I64, P, I64, ctypes.c_int]
    lib.fry_sim_gaussian3d.restype = ctypes.c_int
    print("fry_sim SDK %s ｜ api %d ｜ %s" % (lib.fry_sim_sdk_version().decode(), lib.fry_sim_sdk_api_version(),
                                            lib.fry_sim_sdk_build_info().decode()))
    data = (ctypes.c_float * 5)(0.0, 0.0, 1.0, 0.0, 0.0)
    shape = (ctypes.c_int64 * 3)(1, 1, 5)
    w = (ctypes.c_double * 3)(0.25, 0.5, 0.25)
    rc = lib.fry_sim_gaussian3d(data, shape, None, 0, None, 0, w, 3, 1)
    if rc != 0:
        print("✗ rc=%d %s" % (rc, lib.fry_sim_last_error().decode("utf-8", "replace")))
        return 1
    got = list(data)
    ok = got == [0.0, 0.25, 0.5, 0.25, 0.0]
    print("%s gaussian3d 脉冲 → %s" % ("✓" if ok else "✗", got))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
