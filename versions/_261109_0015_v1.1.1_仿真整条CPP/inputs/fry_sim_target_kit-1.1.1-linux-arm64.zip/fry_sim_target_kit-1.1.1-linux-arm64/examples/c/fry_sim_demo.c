/* examples/c/fry_sim_demo.c —— 纯 C 消费方示例：包含 fry_sim_sdk.h、链 fry_sim、调一次 fry_sim_gaussian3d。
 * 证明两件事：① 头文件能被 C99 编译器包含（没有 C++ 专有语法）；② 库能被加载、能算、结果与手算一致。
 * 例子：一个 1×1×5 的「脉冲」[0,0,1,0,0] 沿最后一轴用 [0.25,0.5,0.25] 平滑 ⇒ 应得 [0,0.25,0.5,0.25,0]（全是 2 的幂，逐位精确）。
 */
#include <stdio.h>
#include <string.h>
#include "fry_sim_sdk.h"

int main(void) {
    float data[5] = {0.0f, 0.0f, 1.0f, 0.0f, 0.0f};
    const float want[5] = {0.0f, 0.25f, 0.5f, 0.25f, 0.0f};
    const int64_t shape[3] = {1, 1, 5};
    const double w[3] = {0.25, 0.5, 0.25};
    int rc, i, ok = 1;
    printf("fry_sim SDK %s ｜ api %d ｜ core %s\n", fry_sim_sdk_version(), fry_sim_sdk_api_version(), fry_sim_version());
    printf("fingerprint %.16s ｜ %s\n", fry_sim_sdk_fingerprint(), fry_sim_sdk_build_info());
    rc = fry_sim_gaussian3d(data, shape, NULL, 0, NULL, 0, w, 3, 1);
    if (rc != 0) {
        printf("✗ rc=%d %s\n", rc, fry_sim_last_error());
        return 1;
    }
    for (i = 0; i < 5; ++i) ok = ok && memcmp(&data[i], &want[i], sizeof(float)) == 0;
    printf("%s gaussian3d 脉冲 → [%g %g %g %g %g]\n", ok ? "✓" : "✗", data[0], data[1], data[2], data[3], data[4]);
    return ok ? 0 : 1;
}
