/* fry_sim_sdk.h —— 仿真 SDK（fry_sim）对外 C 接口。
 *
 * 一个动态库：Windows fry_sim.dll ｜ Linux fry_sim.so ｜ macOS fry_sim.dylib（三平台同名，前缀都不加 lib，
 * 与算法仓 rip_components/fry_kernel/sim_cpp.py 的找库规则一致）。
 *
 * 里面是什么：算法仓 fry_sim_cpp/ 的仿真 C++（★458 起是**整条流程**：fry_sim_run_job 给 BMP 文件夹、出六视图 PNG / 仿真 GLB；
 *   与 Python 同机比：六视图像素逐个相同、GLB 逐字节相同）。下面的计算核心（最费时、与 Python **逐位相同**的几段）仍单独导出，供对账：
 *   ① fry_sim_gaussian3d          占据场三维高斯平滑（= scipy.ndimage.gaussian_filter, mode='reflect'）
 *   ② fry_sim_normal_fields       法线场：表面点 + 梯度（同组视图共用一次平滑）
 *   ③ fry_sim_normal_sample_fold  六视图：沿法线采样 + 逐层叠加（Saunderson 之前）
 *   ④ fry_sim_ray_columns_fold    仿真 GLB：足迹射线读材料柱 + 逐层叠加（Saunderson 之前）
 * 读 BMP、定向、层光学系数表、Saunderson、出图、写 PNG / GLB 仍在调用方（算法仓的 Python）里。
 *
 * 约定：所有数组由调用方分配、C 连续或按 stride 给出；返回 0 = 成功，非 0 = 失败（fry_sim_last_error() 取原因，线程局部）；
 *       线程数 <= 1 = 单线程，线程数不影响结果（逐位）。
 * 版本：fry_sim_sdk_api_version() 是**接口**版本（加函数不变、改签名 +1）；fry_sim_sdk_version() 是**发布**版本；
 *       fry_sim_sdk_fingerprint() 是算法载荷的 tree_sha256（cpp.lock.json），一句话回答「里面是哪一版算法」。
 */
#ifndef FRY_SIM_SDK_H
#define FRY_SIM_SDK_H

#include <stdint.h>

#if defined(_WIN32)
#  if defined(FRY_SIM_SDK_BUILDING)
#    define FRY_SIM_SDK_API __declspec(dllexport)
#  else
#    define FRY_SIM_SDK_API __declspec(dllimport)
#  endif
#else
#  define FRY_SIM_SDK_API __attribute__((visibility("default")))
#endif

#define FRY_SIM_SDK_API_VERSION 2   /* ★458 接口 2：+ 整条流程 fry_sim_run_job / fry_sim_last_report、fry_sim_gauss_weights、fry_sim_marching_cubes */

#ifdef __cplusplus
extern "C" {
#endif

/* ── SDK 自报（本仓 src/sdk/fry_sim_sdk.cpp）────────────────────────────── */
FRY_SIM_SDK_API int fry_sim_sdk_api_version(void);            /* = FRY_SIM_SDK_API_VERSION */
FRY_SIM_SDK_API const char* fry_sim_sdk_version(void);        /* 发布版本，如 "1.0.0"；本地出包 "0.0.0-dev" */
FRY_SIM_SDK_API const char* fry_sim_sdk_fingerprint(void);    /* 载荷 tree_sha256（64 位十六进制） */
FRY_SIM_SDK_API const char* fry_sim_sdk_build_info(void);     /* 编译器 / 平台 / 浮点纪律，一行文字 */

/* ── 计算核心（算法仓 fry_sim_cpp/include/fry_sim/fry_sim_api.h 的同一组函数；签名逐字一致，测试会比对）── */
FRY_SIM_SDK_API const char* fry_sim_version(void);
FRY_SIM_SDK_API const char* fry_sim_last_error(void);

FRY_SIM_SDK_API int fry_sim_gaussian3d(float* data, const int64_t shape[3],
                                       const double* w0, int64_t w0_len, const double* w1, int64_t w1_len,
                                       const double* w2, int64_t w2_len, int threads);

FRY_SIM_SDK_API int fry_sim_normal_fields(const uint8_t* can_p00, const int64_t shape[3], const int64_t stride[3],
                                          const uint8_t* substance_lut, int transparent_code, int include_transparent,
                                          const double* w0, int64_t w0_len, const double* w1, int64_t w1_len,
                                          const double* w2, int64_t w2_len, int64_t max_vox,
                                          const uint8_t* flips, int64_t n_views,
                                          uint8_t* hit, int64_t* first, float* g0, float* g1, float* g2, int threads);

FRY_SIM_SDK_API int fry_sim_normal_sample_fold(const uint8_t* v_p00, const int64_t shape[3], const int64_t stride[3],
                                               const float* n0, const float* n1, const float* n2,
                                               const int64_t* first, const uint8_t* hit,
                                               const float* t, int64_t S, float mm_r, float mm_c, float mm_v,
                                               const double* offs, int64_t n_offs, uint8_t null_code,
                                               const uint8_t* part_lut, const float* Rl, const float* T2, const float* R0,
                                               float* out, int threads);

FRY_SIM_SDK_API int fry_sim_ray_columns_fold(const uint8_t* vol, const int64_t sh[3], const double vm[3],
                                             const double* pts, const double* nrm, int64_t N,
                                             const double* ts, int64_t nt, int64_t nwin,
                                             const uint8_t* solid_lut, uint8_t null_code,
                                             const uint8_t* part_lut, const float* Rl, const float* T2, const float* R0,
                                             uint8_t* cols_out, float* rgb_out, int threads);

/* ── ★458 整条仿真流程（给 BMP 文件夹 → 出六视图 PNG / 仿真 GLB）+ 两个可单独对账的子步骤 ───────────────
 * job_json_utf8 = UTF-8 JSON 作业单（task_str = "six_view" / "sim_glb"；字段见 README「作业单」一节、golden/folder/ 里的样例）。
 * 报告（JSON）用 fry_sim_last_report() 取（本线程，下次调用前有效）。返回 0 = 成功。 */
FRY_SIM_SDK_API int fry_sim_run_job(const char* job_json_utf8);
FRY_SIM_SDK_API const char* fry_sim_last_report(void);
FRY_SIM_SDK_API int fry_sim_gauss_weights(double sigma, double truncate, double* out, int64_t cap, int64_t* n);
FRY_SIM_SDK_API int fry_sim_marching_cubes(const float* im, const int64_t shape[3], double level,
                                           float* verts, int64_t vcap, int32_t* faces, int64_t fcap, int64_t counts[2]);

#ifdef __cplusplus
}
#endif

#endif /* FRY_SIM_SDK_H */
